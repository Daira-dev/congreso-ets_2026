@echo off
setlocal EnableDelayedExpansion
title Instalador del Sistema - Congreso ETS 2026

:: Posicionarse en la carpeta donde reside este script
cd /d "%~dp0"

echo.
echo  ========================================================================
echo    CONGRESO ETS 2026 - DETS GCABA
echo    Instalador para Microsoft Windows 10 y 11 (64-bit)
echo  ========================================================================
echo.

:: 1. Comprobar privilegios (informativo, no bloqueante)
net session >nul 2>&1
if %errorlevel% equ 0 (
    echo  [OK] Ejecutando con privilegios de Administrador.
) else (
    echo  [i]  Ejecutando con permisos de usuario local.
    echo       (Para instalar en carpetas protegidas como C:\Program Files,
    echo        haga clic derecho y elija 'Ejecutar como administrador')
)
echo.

:: 2. Localizar script de instalacion de PowerShell
set "SCRIPT_PS1=%~dp0scripts\instalar.ps1"
if not exist "%SCRIPT_PS1%" (
    if exist "%~dp0windows-installer\scripts\instalar.ps1" (
        set "SCRIPT_PS1=%~dp0windows-installer\scripts\instalar.ps1"
    )
)

if not exist "%SCRIPT_PS1%" (
    echo  [ERROR CRITICO] No se encontro el archivo de instalacion:
    echo          %~dp0scripts\instalar.ps1
    echo.
    echo  Asegurese de extraer todos los archivos del paquete antes de ejecutar este instalador.
    echo.
    pause
    exit /b 1
)

:: 3. Lanzar el asistente de PowerShell con politicas de ejecucion liberadas
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_PS1%"

if %errorlevel% neq 0 (
    echo.
    echo  [AVISO] El instalador finalizo con advertencias o fue cancelado por el usuario.
    echo.
)

echo.
echo Presione cualquier tecla para cerrar esta ventana...
pause >nul
