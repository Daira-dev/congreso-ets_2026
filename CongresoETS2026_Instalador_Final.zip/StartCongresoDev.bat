@echo off
REM Asegurar que la politica de ejecucion no bloquee scripts
powershell -Command "Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force"

REM Iniciar el backend en una nueva ventana
cd C:\Congreso2026\backend
start "Congreso Backend" cmd /k "npm run dev"

REM Iniciar el frontend en una nueva ventana
cd C:\Congreso2026\frontend
start "Congreso Frontend" cmd /k "npm run dev"
