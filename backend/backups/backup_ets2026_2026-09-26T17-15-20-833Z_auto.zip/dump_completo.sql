--
-- PostgreSQL database dump
--

\restrict hPbZhfsIISlKdoS8prtMglNM8QJ9au31tJuQqYUZifulmLoqH5Mfc8zo1piaG3u

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.usuarios DROP CONSTRAINT IF EXISTS usuarios_rol_principal_id_fkey;
ALTER TABLE IF EXISTS ONLY public.usuarios DROP CONSTRAINT IF EXISTS usuarios_evento_id_fkey;
ALTER TABLE IF EXISTS ONLY public.usuarios DROP CONSTRAINT IF EXISTS usuarios_estado_inscripcion_id_fkey;
ALTER TABLE IF EXISTS ONLY public.usuario_roles_adicionales DROP CONSTRAINT IF EXISTS usuario_roles_adicionales_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.usuario_roles_adicionales DROP CONSTRAINT IF EXISTS usuario_roles_adicionales_rol_id_fkey;
ALTER TABLE IF EXISTS ONLY public.suscripciones_push DROP CONSTRAINT IF EXISTS suscripciones_push_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.operadores DROP CONSTRAINT IF EXISTS operadores_rol_id_fkey;
ALTER TABLE IF EXISTS ONLY public.operadores DROP CONSTRAINT IF EXISTS operadores_punto_acceso_default_id_fkey;
ALTER TABLE IF EXISTS ONLY public.logs_auditoria DROP CONSTRAINT IF EXISTS logs_auditoria_usuario_afectado_id_fkey;
ALTER TABLE IF EXISTS ONLY public.homologaciones_expositores DROP CONSTRAINT IF EXISTS homologaciones_expositores_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.homologaciones_expositores DROP CONSTRAINT IF EXISTS homologaciones_expositores_funcionario_validador_id_fkey;
ALTER TABLE IF EXISTS ONLY public.homologaciones_expositores DROP CONSTRAINT IF EXISTS homologaciones_expositores_funcionario_anulador_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuestas DROP CONSTRAINT IF EXISTS encuestas_evento_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas DROP CONSTRAINT IF EXISTS encuesta_respuestas_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas DROP CONSTRAINT IF EXISTS encuesta_respuestas_rol_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas DROP CONSTRAINT IF EXISTS encuesta_respuestas_encuesta_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas_detalles DROP CONSTRAINT IF EXISTS encuesta_respuestas_detalles_respuesta_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas_detalles DROP CONSTRAINT IF EXISTS encuesta_respuestas_detalles_pregunta_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas_detalles DROP CONSTRAINT IF EXISTS encuesta_respuestas_detalles_opcion_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas_detalles DROP CONSTRAINT IF EXISTS encuesta_respuestas_detalles_categoria_tematica_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_preguntas DROP CONSTRAINT IF EXISTS encuesta_preguntas_encuesta_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_preguntas DROP CONSTRAINT IF EXISTS encuesta_preguntas_categoria_tematica_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_opciones DROP CONSTRAINT IF EXISTS encuesta_opciones_pregunta_id_fkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_opciones DROP CONSTRAINT IF EXISTS encuesta_opciones_categoria_tematica_id_fkey;
ALTER TABLE IF EXISTS ONLY public.confirmaciones_asistencia DROP CONSTRAINT IF EXISTS confirmaciones_asistencia_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.certificados DROP CONSTRAINT IF EXISTS certificados_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.certificados DROP CONSTRAINT IF EXISTS certificados_evento_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actividades DROP CONSTRAINT IF EXISTS actividades_tipo_acreditacion_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actividades DROP CONSTRAINT IF EXISTS actividades_punto_acceso_id_fkey;
ALTER TABLE IF EXISTS ONLY public.actividades DROP CONSTRAINT IF EXISTS actividades_evento_id_fkey;
ALTER TABLE IF EXISTS ONLY public.acreditaciones DROP CONSTRAINT IF EXISTS acreditaciones_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.acreditaciones DROP CONSTRAINT IF EXISTS acreditaciones_tipo_acreditacion_id_fkey;
ALTER TABLE IF EXISTS ONLY public.acreditaciones DROP CONSTRAINT IF EXISTS acreditaciones_punto_acceso_id_fkey;
ALTER TABLE IF EXISTS ONLY public.acreditaciones DROP CONSTRAINT IF EXISTS acreditaciones_operador_id_fkey;
ALTER TABLE IF EXISTS ONLY public.acreditaciones DROP CONSTRAINT IF EXISTS acreditaciones_actividad_id_fkey;
DROP TRIGGER IF EXISTS trigger_intercept_blacklist ON public.usuarios;
DROP INDEX IF EXISTS public.idx_usuarios_rol;
DROP INDEX IF EXISTS public.idx_usuarios_evento;
DROP INDEX IF EXISTS public.idx_usuarios_estado;
DROP INDEX IF EXISTS public.idx_usuarios_dni_evento;
DROP INDEX IF EXISTS public.idx_encuestas_evento;
DROP INDEX IF EXISTS public.idx_encuestas_etapa;
DROP INDEX IF EXISTS public.idx_encuesta_respuestas_usuario;
DROP INDEX IF EXISTS public.idx_encuesta_respuestas_encuesta;
DROP INDEX IF EXISTS public.idx_encuesta_respuestas_detalles_resp;
DROP INDEX IF EXISTS public.idx_encuesta_respuestas_detalles_preg;
DROP INDEX IF EXISTS public.idx_encuesta_respuestas_detalles_cat;
DROP INDEX IF EXISTS public.idx_encuesta_preguntas_encuesta;
DROP INDEX IF EXISTS public.idx_encuesta_opciones_pregunta;
DROP INDEX IF EXISTS public.idx_certificados_usuario;
DROP INDEX IF EXISTS public.idx_certificados_evento;
DROP INDEX IF EXISTS public.idx_certificados_codigo;
DROP INDEX IF EXISTS public.idx_acreditaciones_usuario_fecha;
DROP INDEX IF EXISTS public.idx_acreditaciones_usuario;
DROP INDEX IF EXISTS public.idx_acreditaciones_timestamp;
DROP INDEX IF EXISTS public.idx_acreditaciones_actividad;
ALTER TABLE IF EXISTS ONLY public.usuarios DROP CONSTRAINT IF EXISTS usuarios_pkey;
ALTER TABLE IF EXISTS ONLY public.usuario_roles_adicionales DROP CONSTRAINT IF EXISTS usuario_roles_adicionales_pkey;
ALTER TABLE IF EXISTS ONLY public.certificados DROP CONSTRAINT IF EXISTS uq_usuario_tipo_certificado;
ALTER TABLE IF EXISTS ONLY public.usuarios DROP CONSTRAINT IF EXISTS uq_usuario_dni_evento;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas DROP CONSTRAINT IF EXISTS uq_encuesta_usuario;
ALTER TABLE IF EXISTS ONLY public.tipos_acreditacion DROP CONSTRAINT IF EXISTS tipos_acreditacion_pkey;
ALTER TABLE IF EXISTS ONLY public.tipos_acreditacion DROP CONSTRAINT IF EXISTS tipos_acreditacion_codigo_key;
ALTER TABLE IF EXISTS ONLY public.suscripciones_push DROP CONSTRAINT IF EXISTS suscripciones_push_pkey;
ALTER TABLE IF EXISTS ONLY public.suscripciones_push DROP CONSTRAINT IF EXISTS suscripciones_push_endpoint_key;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_nombre_key;
ALTER TABLE IF EXISTS ONLY public.puntos_acceso DROP CONSTRAINT IF EXISTS puntos_acceso_pkey;
ALTER TABLE IF EXISTS ONLY public.operadores DROP CONSTRAINT IF EXISTS operadores_pkey;
ALTER TABLE IF EXISTS ONLY public.operadores DROP CONSTRAINT IF EXISTS operadores_email_institucional_key;
ALTER TABLE IF EXISTS ONLY public.logs_auditoria DROP CONSTRAINT IF EXISTS logs_auditoria_pkey;
ALTER TABLE IF EXISTS ONLY public.homologaciones_expositores DROP CONSTRAINT IF EXISTS homologaciones_expositores_usuario_id_key;
ALTER TABLE IF EXISTS ONLY public.homologaciones_expositores DROP CONSTRAINT IF EXISTS homologaciones_expositores_pkey;
ALTER TABLE IF EXISTS ONLY public.eventos DROP CONSTRAINT IF EXISTS eventos_pkey;
ALTER TABLE IF EXISTS ONLY public.eventos DROP CONSTRAINT IF EXISTS eventos_codigo_key;
ALTER TABLE IF EXISTS ONLY public.estados_inscripcion DROP CONSTRAINT IF EXISTS estados_inscripcion_pkey;
ALTER TABLE IF EXISTS ONLY public.estados_inscripcion DROP CONSTRAINT IF EXISTS estados_inscripcion_codigo_key;
ALTER TABLE IF EXISTS ONLY public.encuestas DROP CONSTRAINT IF EXISTS encuestas_pkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas DROP CONSTRAINT IF EXISTS encuesta_respuestas_pkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_respuestas_detalles DROP CONSTRAINT IF EXISTS encuesta_respuestas_detalles_pkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_preguntas DROP CONSTRAINT IF EXISTS encuesta_preguntas_pkey;
ALTER TABLE IF EXISTS ONLY public.encuesta_opciones DROP CONSTRAINT IF EXISTS encuesta_opciones_pkey;
ALTER TABLE IF EXISTS ONLY public.confirmaciones_asistencia DROP CONSTRAINT IF EXISTS confirmaciones_asistencia_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.confirmaciones_asistencia DROP CONSTRAINT IF EXISTS confirmaciones_asistencia_pkey;
ALTER TABLE IF EXISTS ONLY public.configuraciones_sistema DROP CONSTRAINT IF EXISTS configuraciones_sistema_pkey;
ALTER TABLE IF EXISTS ONLY public.certificados DROP CONSTRAINT IF EXISTS certificados_pkey;
ALTER TABLE IF EXISTS ONLY public.certificados DROP CONSTRAINT IF EXISTS certificados_codigo_verificacion_key;
ALTER TABLE IF EXISTS ONLY public.categorias_tematicas DROP CONSTRAINT IF EXISTS categorias_tematicas_pkey;
ALTER TABLE IF EXISTS ONLY public.categorias_tematicas DROP CONSTRAINT IF EXISTS categorias_tematicas_nombre_key;
ALTER TABLE IF EXISTS ONLY public.blacklist DROP CONSTRAINT IF EXISTS blacklist_pkey;
ALTER TABLE IF EXISTS ONLY public.blacklist DROP CONSTRAINT IF EXISTS blacklist_dni_pasaporte_key;
ALTER TABLE IF EXISTS ONLY public.actividades DROP CONSTRAINT IF EXISTS actividades_pkey;
ALTER TABLE IF EXISTS ONLY public.acreditaciones DROP CONSTRAINT IF EXISTS acreditaciones_pkey;
ALTER TABLE IF EXISTS public.tipos_acreditacion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.suscripciones_push ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.puntos_acceso ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.operadores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.logs_auditoria ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.homologaciones_expositores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.eventos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.estados_inscripcion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.encuestas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.encuesta_respuestas_detalles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.encuesta_preguntas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.encuesta_opciones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.confirmaciones_asistencia ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categorias_tematicas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blacklist ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.actividades ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.usuarios;
DROP TABLE IF EXISTS public.usuario_roles_adicionales;
DROP SEQUENCE IF EXISTS public.tipos_acreditacion_id_seq;
DROP TABLE IF EXISTS public.tipos_acreditacion;
DROP SEQUENCE IF EXISTS public.suscripciones_push_id_seq;
DROP TABLE IF EXISTS public.suscripciones_push;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP SEQUENCE IF EXISTS public.puntos_acceso_id_seq;
DROP TABLE IF EXISTS public.puntos_acceso;
DROP SEQUENCE IF EXISTS public.operadores_id_seq;
DROP TABLE IF EXISTS public.operadores;
DROP SEQUENCE IF EXISTS public.logs_auditoria_id_seq;
DROP TABLE IF EXISTS public.logs_auditoria;
DROP SEQUENCE IF EXISTS public.homologaciones_expositores_id_seq;
DROP TABLE IF EXISTS public.homologaciones_expositores;
DROP SEQUENCE IF EXISTS public.eventos_id_seq;
DROP TABLE IF EXISTS public.eventos;
DROP SEQUENCE IF EXISTS public.estados_inscripcion_id_seq;
DROP TABLE IF EXISTS public.estados_inscripcion;
DROP SEQUENCE IF EXISTS public.encuestas_id_seq;
DROP TABLE IF EXISTS public.encuestas;
DROP SEQUENCE IF EXISTS public.encuesta_respuestas_detalles_id_seq;
DROP TABLE IF EXISTS public.encuesta_respuestas_detalles;
DROP TABLE IF EXISTS public.encuesta_respuestas;
DROP SEQUENCE IF EXISTS public.encuesta_preguntas_id_seq;
DROP TABLE IF EXISTS public.encuesta_preguntas;
DROP SEQUENCE IF EXISTS public.encuesta_opciones_id_seq;
DROP TABLE IF EXISTS public.encuesta_opciones;
DROP SEQUENCE IF EXISTS public.confirmaciones_asistencia_id_seq;
DROP TABLE IF EXISTS public.confirmaciones_asistencia;
DROP TABLE IF EXISTS public.configuraciones_sistema;
DROP TABLE IF EXISTS public.certificados;
DROP SEQUENCE IF EXISTS public.categorias_tematicas_id_seq;
DROP TABLE IF EXISTS public.categorias_tematicas;
DROP SEQUENCE IF EXISTS public.blacklist_id_seq;
DROP TABLE IF EXISTS public.blacklist;
DROP SEQUENCE IF EXISTS public.actividades_id_seq;
DROP TABLE IF EXISTS public.actividades;
DROP TABLE IF EXISTS public.acreditaciones;
DROP FUNCTION IF EXISTS public.trg_check_blacklist();
DROP FUNCTION IF EXISTS public.registrar_usuario_seguro(p_dni_pasaporte character varying, p_nombre character varying, p_apellido character varying, p_email character varying, p_celular character varying, p_rol_principal_id integer, p_foto_url text, p_foto_metadata jsonb, p_es_superadmin_override boolean, p_evento_id integer);
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: registrar_usuario_seguro(character varying, character varying, character varying, character varying, character varying, integer, text, jsonb, boolean, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.registrar_usuario_seguro(p_dni_pasaporte character varying, p_nombre character varying, p_apellido character varying, p_email character varying, p_celular character varying, p_rol_principal_id integer, p_foto_url text, p_foto_metadata jsonb, p_es_superadmin_override boolean DEFAULT false, p_evento_id integer DEFAULT NULL::integer) RETURNS TABLE(new_id uuid, estado_codigo character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id_sancionado INT;
    v_count INT;
    v_estado_id INT;
    v_estado_codigo VARCHAR(30);
    v_inserted_id UUID;
    v_id_confirmado INT;
    v_id_espera INT;
    v_id_cancelado INT;
    v_id_baja INT;
    v_en_blacklist BOOLEAN;
    v_max_cupo INT := 400;
    v_evento_id INT;
    v_usuario_existente_id UUID;
    v_estado_actual_id INT;
BEGIN
    -- Determinar evento de destino (por parÃƒÂ¡metro o evento activo por defecto)
    IF p_evento_id IS NOT NULL THEN
        v_evento_id := p_evento_id;
    ELSE
        SELECT id INTO v_evento_id FROM eventos WHERE activo = TRUE ORDER BY anio DESC LIMIT 1;
        IF v_evento_id IS NULL THEN
            v_evento_id := 1;
        END IF;
    END IF;

    -- Obtener cupo dinÃƒÂ¡mico del evento
    SELECT COALESCE(cupo_maximo, 400) INTO v_max_cupo FROM eventos WHERE id = v_evento_id;
    IF v_max_cupo IS NULL THEN
        v_max_cupo := 400;
    END IF;

    -- Obtener IDs de estados normalizados
    SELECT id INTO v_id_confirmado FROM estados_inscripcion WHERE codigo = 'CONFIRMADO';
    SELECT id INTO v_id_espera FROM estados_inscripcion WHERE codigo = 'LISTA_ESPERA';
    SELECT id INTO v_id_sancionado FROM estados_inscripcion WHERE codigo = 'SANCIONADO';
    SELECT id INTO v_id_cancelado FROM estados_inscripcion WHERE codigo = 'CANCELADO';
    SELECT id INTO v_id_baja FROM estados_inscripcion WHERE codigo = 'BAJA_AUTOMATICA';

    -- Validar si el DNI figura en blacklist
    SELECT EXISTS (
        SELECT 1 FROM blacklist WHERE dni_pasaporte = p_dni_pasaporte AND activo = TRUE
    ) INTO v_en_blacklist;

    -- Determinar estado que corresponderÃƒÂ­a
    IF p_es_superadmin_override THEN
        PERFORM set_config('app.superadmin_override', 'true', true);
        v_estado_id := v_id_confirmado;
        v_estado_codigo := 'CONFIRMADO';
    ELSIF v_en_blacklist THEN
        PERFORM set_config('app.superadmin_override', 'false', true);
        v_estado_id := v_id_sancionado;
        v_estado_codigo := 'SANCIONADO';
    ELSE
        PERFORM set_config('app.superadmin_override', 'false', true);

        -- Bloqueo pesimista del evento para control estricto de concurrencia
        PERFORM 1 FROM eventos WHERE id = v_evento_id FOR UPDATE;

        SELECT COUNT(*) INTO v_count 
        FROM usuarios 
        WHERE estado_inscripcion_id = v_id_confirmado AND evento_id = v_evento_id;

        -- Cupo protegido protocolar: Autoridades (Rol 4) y Expositores (Rol 3) tienen reserva institucional
        IF p_rol_principal_id IN (3, 4) THEN
            v_estado_id := v_id_confirmado;
            v_estado_codigo := 'CONFIRMADO';
        ELSIF v_count < v_max_cupo THEN
            v_estado_id := v_id_confirmado;
            v_estado_codigo := 'CONFIRMADO';
        ELSE
            v_estado_id := v_id_espera;
            v_estado_codigo := 'LISTA_ESPERA';
        END IF;
    END IF;

    -- Verificar si el usuario ya existe en este evento especÃƒÂ­fico
    SELECT id, estado_inscripcion_id INTO v_usuario_existente_id, v_estado_actual_id
    FROM usuarios
    WHERE dni_pasaporte = p_dni_pasaporte AND evento_id = v_evento_id;

    IF v_usuario_existente_id IS NOT NULL THEN
        -- Si estaba CANCELADO o BAJA_AUTOMATICA, se reactiva con sus nuevos datos y nuevo estado
        IF v_estado_actual_id IN (v_id_cancelado, v_id_baja) THEN
            UPDATE usuarios
            SET nombre = p_nombre,
                apellido = p_apellido,
                email = p_email,
                celular = p_celular,
                rol_principal_id = p_rol_principal_id,
                estado_inscripcion_id = v_estado_id,
                foto_url = COALESCE(p_foto_url, foto_url),
                foto_metadata = COALESCE(p_foto_metadata, foto_metadata),
                actualizado_en = NOW()
            WHERE id = v_usuario_existente_id
            RETURNING id INTO v_inserted_id;

            -- Registrar en auditorÃƒÂ­a la reactivaciÃƒÂ³n
            INSERT INTO logs_auditoria (evento, actor_usuario, usuario_afectado_id, detalles, timestamp)
            VALUES ('REINSCRIPCION_USUARIO_REACTIVADO', 'SISTEMA', v_inserted_id, 
                    json_build_object('dni', p_dni_pasaporte, 'evento_id', v_evento_id, 'nuevo_estado', v_estado_codigo)::jsonb, NOW());
        ELSE
            -- Ya existe activo en este evento
            RAISE EXCEPTION 'ERR_DNI_ALREADY_EXISTS: El DNI ya se encuentra registrado para este evento.'
                USING ERRCODE = '23505';
        END IF;
    ELSE
        -- InserciÃƒÂ³n limpia de nueva persona/inscripciÃƒÂ³n en el evento
        INSERT INTO usuarios (
            dni_pasaporte, nombre, apellido, email, celular,
            rol_principal_id, estado_inscripcion_id, foto_url, foto_metadata, evento_id
        ) VALUES (
            p_dni_pasaporte, p_nombre, p_apellido, p_email, p_celular,
            p_rol_principal_id, v_estado_id, p_foto_url, p_foto_metadata, v_evento_id
        ) RETURNING id INTO v_inserted_id;
    END IF;

    -- Si el rol principal es 'Expositor', inicializar homologaciÃƒÂ³n si no existe
    IF EXISTS (SELECT 1 FROM roles WHERE id = p_rol_principal_id AND nombre = 'Expositor') THEN
        INSERT INTO homologaciones_expositores (usuario_id, estado_homologacion)
        VALUES (v_inserted_id, 'PENDIENTE')
        ON CONFLICT (usuario_id) DO NOTHING;
    END IF;

    RETURN QUERY SELECT v_inserted_id, v_estado_codigo;
END;
$$;


--
-- Name: trg_check_blacklist(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_check_blacklist() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id_sancionado INT;
BEGIN
    -- Si la sesiÃƒÂ³n tiene superadmin_override activo en transacciÃƒÂ³n, permitir
    IF current_setting('app.superadmin_override', true) = 'true' THEN
        RETURN NEW;
    END IF;

    IF EXISTS (SELECT 1 FROM blacklist WHERE dni_pasaporte = NEW.dni_pasaporte AND activo = TRUE) THEN
        SELECT id INTO v_id_sancionado FROM estados_inscripcion WHERE codigo = 'SANCIONADO';
        NEW.estado_inscripcion_id := v_id_sancionado;
    END IF;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acreditaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acreditaciones (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    usuario_id uuid NOT NULL,
    operador_id integer NOT NULL,
    tipo_acreditacion_id integer NOT NULL,
    actividad_id integer,
    punto_acceso_id integer NOT NULL,
    es_manual boolean DEFAULT false NOT NULL,
    motivo_manual text,
    tipo_movimiento character varying(20) DEFAULT 'INGRESO'::character varying NOT NULL,
    timestamp_acreditacion timestamp with time zone DEFAULT now(),
    CONSTRAINT acreditaciones_tipo_movimiento_check CHECK (((tipo_movimiento)::text = ANY ((ARRAY['INGRESO'::character varying, 'EGRESO'::character varying])::text[])))
);


--
-- Name: actividades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actividades (
    id integer NOT NULL,
    evento_id integer,
    nombre character varying(150) NOT NULL,
    descripcion text,
    tipo_acreditacion_id integer NOT NULL,
    punto_acceso_id integer NOT NULL,
    cupo_maximo integer DEFAULT 50 NOT NULL,
    horario_inicio timestamp with time zone NOT NULL,
    horario_fin timestamp with time zone NOT NULL,
    disertante_nombre character varying(150),
    activo boolean DEFAULT true NOT NULL
);


--
-- Name: actividades_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actividades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actividades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actividades_id_seq OWNED BY public.actividades.id;


--
-- Name: blacklist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blacklist (
    id integer NOT NULL,
    dni_pasaporte character varying(50) NOT NULL,
    motivo text NOT NULL,
    registrado_por character varying(100) DEFAULT 'SISTEMA'::character varying,
    registrado_en timestamp with time zone DEFAULT now(),
    activo boolean DEFAULT true NOT NULL
);


--
-- Name: blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.blacklist_id_seq OWNED BY public.blacklist.id;


--
-- Name: categorias_tematicas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorias_tematicas (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    activo boolean DEFAULT true NOT NULL,
    creado_en timestamp with time zone DEFAULT now()
);


--
-- Name: categorias_tematicas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categorias_tematicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categorias_tematicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categorias_tematicas_id_seq OWNED BY public.categorias_tematicas.id;


--
-- Name: certificados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.certificados (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    codigo_verificacion character varying(50) NOT NULL,
    usuario_id uuid NOT NULL,
    evento_id integer DEFAULT 1,
    tipo_certificado character varying(50) DEFAULT 'ASISTENCIA'::character varying NOT NULL,
    horas_catedra integer DEFAULT 16 NOT NULL,
    emitido_en timestamp with time zone DEFAULT now(),
    metadata jsonb,
    CONSTRAINT certificados_tipo_certificado_check CHECK (((tipo_certificado)::text = ANY ((ARRAY['ASISTENCIA'::character varying, 'EXPOSITOR'::character varying, 'DISERTANTE'::character varying, 'ORGANIZADOR'::character varying])::text[])))
);


--
-- Name: configuraciones_sistema; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configuraciones_sistema (
    clave character varying(100) NOT NULL,
    valor jsonb NOT NULL,
    descripcion text,
    categoria character varying(50) DEFAULT 'GENERAL'::character varying,
    actualizado_en timestamp with time zone DEFAULT now()
);


--
-- Name: confirmaciones_asistencia; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.confirmaciones_asistencia (
    id integer NOT NULL,
    usuario_id uuid NOT NULL,
    token_hash character varying(128) NOT NULL,
    emitido_en timestamp with time zone DEFAULT now(),
    expira_en timestamp with time zone NOT NULL,
    confirmado_en timestamp with time zone,
    ip_confirmacion character varying(45)
);


--
-- Name: confirmaciones_asistencia_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.confirmaciones_asistencia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: confirmaciones_asistencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.confirmaciones_asistencia_id_seq OWNED BY public.confirmaciones_asistencia.id;


--
-- Name: encuesta_opciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encuesta_opciones (
    id integer NOT NULL,
    pregunta_id integer NOT NULL,
    categoria_tematica_id integer,
    orden integer DEFAULT 1 NOT NULL,
    texto_opcion character varying(250) NOT NULL,
    valor_ponderacion numeric(4,2) DEFAULT 1.00 NOT NULL
);


--
-- Name: encuesta_opciones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.encuesta_opciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encuesta_opciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.encuesta_opciones_id_seq OWNED BY public.encuesta_opciones.id;


--
-- Name: encuesta_preguntas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encuesta_preguntas (
    id integer NOT NULL,
    encuesta_id integer NOT NULL,
    categoria_tematica_id integer,
    orden integer DEFAULT 1 NOT NULL,
    texto_pregunta text NOT NULL,
    tipo_pregunta character varying(50) DEFAULT 'OPCION_MULTIPLE'::character varying NOT NULL,
    es_obligatoria boolean DEFAULT false NOT NULL,
    peso_ponderacion numeric(4,2) DEFAULT 1.00 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    CONSTRAINT encuesta_preguntas_tipo_pregunta_check CHECK (((tipo_pregunta)::text = ANY ((ARRAY['OPCION_UNICA'::character varying, 'OPCION_MULTIPLE'::character varying, 'CALIFICACION_1_A_5'::character varying, 'TEXTO_ABIERTO'::character varying])::text[])))
);


--
-- Name: encuesta_preguntas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.encuesta_preguntas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encuesta_preguntas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.encuesta_preguntas_id_seq OWNED BY public.encuesta_preguntas.id;


--
-- Name: encuesta_respuestas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encuesta_respuestas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    encuesta_id integer NOT NULL,
    usuario_id uuid,
    rol_id integer,
    ip_origen character varying(45),
    creado_en timestamp with time zone DEFAULT now()
);


--
-- Name: encuesta_respuestas_detalles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encuesta_respuestas_detalles (
    id bigint NOT NULL,
    respuesta_id uuid NOT NULL,
    pregunta_id integer NOT NULL,
    opcion_id integer,
    categoria_tematica_id integer,
    valor_numerico integer,
    respuesta_texto text
);


--
-- Name: encuesta_respuestas_detalles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.encuesta_respuestas_detalles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encuesta_respuestas_detalles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.encuesta_respuestas_detalles_id_seq OWNED BY public.encuesta_respuestas_detalles.id;


--
-- Name: encuestas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encuestas (
    id integer NOT NULL,
    evento_id integer,
    titulo character varying(150) NOT NULL,
    descripcion text,
    etapa character varying(50) DEFAULT 'INSCRIPCION'::character varying NOT NULL,
    es_obligatoria boolean DEFAULT false NOT NULL,
    activa boolean DEFAULT true NOT NULL,
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone DEFAULT now(),
    CONSTRAINT encuestas_etapa_check CHECK (((etapa)::text = ANY ((ARRAY['INSCRIPCION'::character varying, 'CONFIRMACION'::character varying, 'ACREDITACION'::character varying, 'POST_EVENTO'::character varying, 'SONDEO_ABIERTO'::character varying])::text[])))
);


--
-- Name: encuestas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.encuestas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encuestas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.encuestas_id_seq OWNED BY public.encuestas.id;


--
-- Name: estados_inscripcion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.estados_inscripcion (
    id integer NOT NULL,
    codigo character varying(30) NOT NULL,
    nombre character varying(50) NOT NULL,
    permite_ingreso boolean DEFAULT false NOT NULL,
    descripcion text
);


--
-- Name: estados_inscripcion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.estados_inscripcion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: estados_inscripcion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.estados_inscripcion_id_seq OWNED BY public.estados_inscripcion.id;


--
-- Name: eventos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventos (
    id integer NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(150) NOT NULL,
    lema character varying(250),
    descripcion text,
    anio integer NOT NULL,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    horario_apertura character varying(10) DEFAULT '08:00'::character varying,
    horario_cierre character varying(10) DEFAULT '18:30'::character varying,
    lugar_nombre character varying(150),
    direccion character varying(200),
    ciudad character varying(100),
    cupo_maximo integer DEFAULT 400 NOT NULL,
    estado character varying(30) DEFAULT 'PUBLICADO'::character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    creado_en timestamp with time zone DEFAULT now()
);


--
-- Name: eventos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eventos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eventos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eventos_id_seq OWNED BY public.eventos.id;


--
-- Name: homologaciones_expositores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.homologaciones_expositores (
    id integer NOT NULL,
    usuario_id uuid NOT NULL,
    estado_homologacion character varying(30) DEFAULT 'PENDIENTE'::character varying NOT NULL,
    documentacion_presentada text,
    observaciones text,
    funcionario_validador_id integer,
    fecha_validacion timestamp with time zone,
    funcionario_anulador_id integer,
    fecha_anulacion timestamp with time zone,
    motivo_anulacion text,
    actualizado_en timestamp with time zone DEFAULT now(),
    CONSTRAINT homologaciones_expositores_estado_homologacion_check CHECK (((estado_homologacion)::text = ANY ((ARRAY['PENDIENTE'::character varying, 'VALIDADO'::character varying, 'RECHAZADO'::character varying, 'ANULADO'::character varying])::text[])))
);


--
-- Name: homologaciones_expositores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.homologaciones_expositores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: homologaciones_expositores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.homologaciones_expositores_id_seq OWNED BY public.homologaciones_expositores.id;


--
-- Name: logs_auditoria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logs_auditoria (
    id bigint NOT NULL,
    evento character varying(100) NOT NULL,
    actor_usuario character varying(100) NOT NULL,
    usuario_afectado_id uuid,
    detalles jsonb,
    ip_origen character varying(45),
    "timestamp" timestamp with time zone DEFAULT now()
);


--
-- Name: logs_auditoria_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.logs_auditoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logs_auditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.logs_auditoria_id_seq OWNED BY public.logs_auditoria.id;


--
-- Name: operadores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operadores (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    email_institucional character varying(150) NOT NULL,
    punto_acceso_default_id integer NOT NULL,
    rol_id integer DEFAULT 5 NOT NULL,
    password_hash character varying(255),
    activo boolean DEFAULT true NOT NULL,
    creado_en timestamp with time zone DEFAULT now()
);


--
-- Name: operadores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.operadores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: operadores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.operadores_id_seq OWNED BY public.operadores.id;


--
-- Name: puntos_acceso; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.puntos_acceso (
    id integer NOT NULL,
    evento_id integer,
    nombre character varying(100) NOT NULL,
    ubicacion_fisica character varying(150) NOT NULL,
    tipo_punto character varying(30) DEFAULT 'PUESTO_ACCESO'::character varying NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    creado_en timestamp with time zone DEFAULT now()
);


--
-- Name: puntos_acceso_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.puntos_acceso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: puntos_acceso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.puntos_acceso_id_seq OWNED BY public.puntos_acceso.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text,
    jerarquia integer DEFAULT 1 NOT NULL,
    creado_en timestamp with time zone DEFAULT now()
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: suscripciones_push; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suscripciones_push (
    id integer NOT NULL,
    usuario_id uuid,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    creado_en timestamp with time zone DEFAULT now()
);


--
-- Name: suscripciones_push_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suscripciones_push_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suscripciones_push_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suscripciones_push_id_seq OWNED BY public.suscripciones_push.id;


--
-- Name: tipos_acreditacion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tipos_acreditacion (
    id integer NOT NULL,
    codigo character varying(50) NOT NULL,
    descripcion character varying(150) NOT NULL,
    requiere_actividad boolean DEFAULT false NOT NULL
);


--
-- Name: tipos_acreditacion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tipos_acreditacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tipos_acreditacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tipos_acreditacion_id_seq OWNED BY public.tipos_acreditacion.id;


--
-- Name: usuario_roles_adicionales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuario_roles_adicionales (
    usuario_id uuid NOT NULL,
    rol_id integer NOT NULL,
    asignado_en timestamp with time zone DEFAULT now()
);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dni_pasaporte character varying(50) NOT NULL,
    evento_id integer DEFAULT 1 NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    celular character varying(30) NOT NULL,
    rol_principal_id integer NOT NULL,
    estado_inscripcion_id integer NOT NULL,
    foto_url text,
    foto_metadata jsonb,
    creado_en timestamp with time zone DEFAULT now(),
    actualizado_en timestamp with time zone DEFAULT now()
);


--
-- Name: actividades id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades ALTER COLUMN id SET DEFAULT nextval('public.actividades_id_seq'::regclass);


--
-- Name: blacklist id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blacklist ALTER COLUMN id SET DEFAULT nextval('public.blacklist_id_seq'::regclass);


--
-- Name: categorias_tematicas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorias_tematicas ALTER COLUMN id SET DEFAULT nextval('public.categorias_tematicas_id_seq'::regclass);


--
-- Name: confirmaciones_asistencia id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.confirmaciones_asistencia ALTER COLUMN id SET DEFAULT nextval('public.confirmaciones_asistencia_id_seq'::regclass);


--
-- Name: encuesta_opciones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_opciones ALTER COLUMN id SET DEFAULT nextval('public.encuesta_opciones_id_seq'::regclass);


--
-- Name: encuesta_preguntas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_preguntas ALTER COLUMN id SET DEFAULT nextval('public.encuesta_preguntas_id_seq'::regclass);


--
-- Name: encuesta_respuestas_detalles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas_detalles ALTER COLUMN id SET DEFAULT nextval('public.encuesta_respuestas_detalles_id_seq'::regclass);


--
-- Name: encuestas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuestas ALTER COLUMN id SET DEFAULT nextval('public.encuestas_id_seq'::regclass);


--
-- Name: estados_inscripcion id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estados_inscripcion ALTER COLUMN id SET DEFAULT nextval('public.estados_inscripcion_id_seq'::regclass);


--
-- Name: eventos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventos ALTER COLUMN id SET DEFAULT nextval('public.eventos_id_seq'::regclass);


--
-- Name: homologaciones_expositores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homologaciones_expositores ALTER COLUMN id SET DEFAULT nextval('public.homologaciones_expositores_id_seq'::regclass);


--
-- Name: logs_auditoria id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs_auditoria ALTER COLUMN id SET DEFAULT nextval('public.logs_auditoria_id_seq'::regclass);


--
-- Name: operadores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operadores ALTER COLUMN id SET DEFAULT nextval('public.operadores_id_seq'::regclass);


--
-- Name: puntos_acceso id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.puntos_acceso ALTER COLUMN id SET DEFAULT nextval('public.puntos_acceso_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: suscripciones_push id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suscripciones_push ALTER COLUMN id SET DEFAULT nextval('public.suscripciones_push_id_seq'::regclass);


--
-- Name: tipos_acreditacion id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipos_acreditacion ALTER COLUMN id SET DEFAULT nextval('public.tipos_acreditacion_id_seq'::regclass);


--
-- Data for Name: acreditaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acreditaciones (id, usuario_id, operador_id, tipo_acreditacion_id, actividad_id, punto_acceso_id, es_manual, motivo_manual, tipo_movimiento, timestamp_acreditacion) FROM stdin;
\.


--
-- Data for Name: actividades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actividades (id, evento_id, nombre, descripcion, tipo_acreditacion_id, punto_acceso_id, cupo_maximo, horario_inicio, horario_fin, disertante_nombre, activo) FROM stdin;
\.


--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blacklist (id, dni_pasaporte, motivo, registrado_por, registrado_en, activo) FROM stdin;
\.


--
-- Data for Name: categorias_tematicas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorias_tematicas (id, nombre, descripcion, activo, creado_en) FROM stdin;
1	Inteligencia Artificial y Machine Learning	Modelos generativos, agentes y automatizaciÃ³n inteligente	t	2026-09-26 14:15:13.114964-03
2	Ciberseguridad y ProtecciÃ³n de Datos	Defensa de infraestructuras, normativas y forensia digital	t	2026-09-26 14:15:13.114964-03
3	Desarrollo Cloud y Arquitecturas Web	Sistemas distribuidos, microservicios, DevOps y APIs	t	2026-09-26 14:15:13.114964-03
4	RobÃ³tica, AutomatizaciÃ³n e IoT	Sistemas embebidos, sensores y robÃ³tica aplicada	t	2026-09-26 14:15:13.114964-03
5	InserciÃ³n Laboral y PrÃ¡cticas IFTS	PasantÃ­as, articulaciÃ³n con cÃ¡maras empresariales y mentorÃ­as	t	2026-09-26 14:15:13.114964-03
6	Ciencia de Datos y AnalÃ­tica	Big data, visualizaciÃ³n estratÃ©gica y pipelines de datos	t	2026-09-26 14:15:13.114964-03
\.


--
-- Data for Name: certificados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.certificados (id, codigo_verificacion, usuario_id, evento_id, tipo_certificado, horas_catedra, emitido_en, metadata) FROM stdin;
\.


--
-- Data for Name: configuraciones_sistema; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuraciones_sistema (clave, valor, descripcion, categoria, actualizado_en) FROM stdin;
aforo_maximo_confirmados	{"cupo": 400}	LÃ­mite mÃ¡ximo de inscripciones confirmadas automÃ¡ticas	GENERAL	2026-09-26 14:15:13.099986-03
ventana_reconfirmacion_horas	{"pre_evento_horas": 48, "vigencia_token_horas": 24}	Plazos para el envÃ­o de correos de confirmaciÃ³n y expiraciÃ³n	GENERAL	2026-09-26 14:15:13.099986-03
cron_backup_automatico	{"activo": true, "directorio": "./backups", "diurno_fin": "19:00", "frecuencia": "0 2 * * *", "diurno_activo": true, "diurno_inicio": "08:00", "nocturno_hora": "02:00", "retencion_dias": 15, "nocturno_activo": true, "diurno_intervalo_min": 30}	ProgramaciÃ³n y retenciÃ³n de backups automÃ¡ticos	BACKUP	2026-09-26 14:15:13.099986-03
repositorio_git	{"remoto_url": "", "ruta_local": "/media/nestor/960GB/GIT_Congreso/", "rama_default": "main", "sincronizacion_automatica": false}	ParÃ¡metros del repositorio Git local y sincronizaciÃ³n con remoto	GIT	2026-09-26 14:15:13.099986-03
politica_acreditacion	{"exigir_dni_fisico": true, "mostrar_foto_operador": true, "reloj_animado_credencial": true}	PolÃ­ticas de seguridad operativa en puerta	SEGURIDAD	2026-09-26 14:15:13.099986-03
\.


--
-- Data for Name: confirmaciones_asistencia; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.confirmaciones_asistencia (id, usuario_id, token_hash, emitido_en, expira_en, confirmado_en, ip_confirmacion) FROM stdin;
\.


--
-- Data for Name: encuesta_opciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_opciones (id, pregunta_id, categoria_tematica_id, orden, texto_opcion, valor_ponderacion) FROM stdin;
1	1	1	1	Inteligencia Artificial y Modelos Predictivos	1.00
2	1	2	2	Ciberseguridad Ofensiva y Defensiva	1.00
3	1	3	3	Desarrollo Cloud & Microservicios	1.00
4	1	4	4	RobÃ³tica e Internet de las Cosas (IoT)	1.00
5	1	5	5	PrÃ¡cticas Profesionalizantes e InserciÃ³n en Empresas	1.00
\.


--
-- Data for Name: encuesta_preguntas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_preguntas (id, encuesta_id, categoria_tematica_id, orden, texto_pregunta, tipo_pregunta, es_obligatoria, peso_ponderacion, activo) FROM stdin;
1	1	\N	1	Â¿CuÃ¡les de las siguientes Ã¡reas tÃ©cnicas consideras fundamentales para tu desarrollo profesional?	OPCION_MULTIPLE	t	1.20	t
2	1	\N	2	Â¿QuÃ© nivel de interÃ©s tienes en profundizar sobre Inteligencia Artificial aplicada en la industria?	CALIFICACION_1_A_5	f	1.00	t
3	1	\N	3	Â¿QuÃ© temÃ¡tica o taller especÃ­fico te gustarÃ­a que se incorpore en la prÃ³xima ediciÃ³n?	TEXTO_ABIERTO	f	1.00	t
\.


--
-- Data for Name: encuesta_respuestas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_respuestas (id, encuesta_id, usuario_id, rol_id, ip_origen, creado_en) FROM stdin;
\.


--
-- Data for Name: encuesta_respuestas_detalles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_respuestas_detalles (id, respuesta_id, pregunta_id, opcion_id, categoria_tematica_id, valor_numerico, respuesta_texto) FROM stdin;
\.


--
-- Data for Name: encuestas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuestas (id, evento_id, titulo, descripcion, etapa, es_obligatoria, activa, creado_en, actualizado_en) FROM stdin;
1	1	Sondeo de Intereses y Preferencias TemÃ¡ticas ETS 2026/2027	AyÃºdanos a priorizar los prÃ³ximos talleres, masterclasses y disertaciones tÃ©cnicas.	INSCRIPCION	f	t	2026-09-26 14:15:13.121913-03	2026-09-26 14:15:13.121913-03
\.


--
-- Data for Name: estados_inscripcion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.estados_inscripcion (id, codigo, nombre, permite_ingreso, descripcion) FROM stdin;
1	CONFIRMADO	Confirmado	t	InscripciÃ³n activa con cupo asegurado y credencial habilitada
2	LISTA_ESPERA	Lista de Espera	f	Sin cupo inmediato por capacidad de aforo completada (FIFO)
3	SANCIONADO	Sancionado	f	RestricciÃ³n disciplinaria activa por inclusiÃ³n en Lista Negra / Blacklist
4	BAJA_AUTOMATICA	Baja AutomÃ¡tica 48hs	f	No confirmÃ³ asistencia en la ventana de 24hs tras el aviso de 48hs
5	CANCELADO	Cancelado	f	Baja voluntaria o revocada manualmente
\.


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventos (id, codigo, nombre, lema, descripcion, anio, fecha_inicio, fecha_fin, horario_apertura, horario_cierre, lugar_nombre, direccion, ciudad, cupo_maximo, estado, activo, creado_en) FROM stdin;
1	ETS_2026	1er Congreso de EducaciÃ³n TÃ©cnica Superior 2026	\N	EdiciÃ³n inaugural en Auditorio Polo Saavedra	2026	2026-11-06	2026-11-06	08:00	18:30	\N	\N	\N	400	PUBLICADO	t	2026-09-26 14:15:13.105012-03
2	ETS_2027	2do Congreso de EducaciÃ³n TÃ©cnica Superior 2027	\N	EdiciÃ³n de consolidaciÃ³n y nuevas especialidades	2027	2027-11-05	2027-11-05	08:00	18:30	\N	\N	\N	400	PUBLICADO	t	2026-09-26 14:15:13.105012-03
\.


--
-- Data for Name: homologaciones_expositores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.homologaciones_expositores (id, usuario_id, estado_homologacion, documentacion_presentada, observaciones, funcionario_validador_id, fecha_validacion, funcionario_anulador_id, fecha_anulacion, motivo_anulacion, actualizado_en) FROM stdin;
\.


--
-- Data for Name: logs_auditoria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logs_auditoria (id, evento, actor_usuario, usuario_afectado_id, detalles, ip_origen, "timestamp") FROM stdin;
1	BAJA_AUTOMATICA_48HS	CRON_SISTEMA	\N	{"evento_id": 1, "bajas_count": 0}	\N	2026-09-26 14:15:20.801122-03
2	CRON_48HS_DESPACHADO	SISTEMA	\N	{"lotes": 0, "evento_id": 1, "total_confirmados": 0}	\N	2026-09-26 14:15:20.831665-03
\.


--
-- Data for Name: operadores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operadores (id, nombre, apellido, email_institucional, punto_acceso_default_id, rol_id, password_hash, activo, creado_en) FROM stdin;
\.


--
-- Data for Name: puntos_acceso; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.puntos_acceso (id, evento_id, nombre, ubicacion_fisica, tipo_punto, activo, creado_en) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, nombre, descripcion, jerarquia, creado_en) FROM stdin;
1	Estudiante	Estudiante de Nivel TÃ©cnico Superior o afÃ­n	1	2026-09-26 14:15:13.043449-03
2	Docente	Personal acadÃ©mico / Docente	1	2026-09-26 14:15:13.043449-03
3	Expositor	Disertante o Tallerista con requerimiento de homologaciÃ³n	2	2026-09-26 14:15:13.043449-03
4	Autoridad	Autoridad Institucional / Ministerial / Invitado Especial	2	2026-09-26 14:15:13.043449-03
5	Operador	Personal de acreditaciÃ³n en puertas y aulas	3	2026-09-26 14:15:13.043449-03
6	Verificador	Funcionario habilitado para homologar pergaminos de expositores	4	2026-09-26 14:15:13.043449-03
7	Administrador	Personal directivo DETS para control y gestiÃ³n	4	2026-09-26 14:15:13.043449-03
8	Superadmin	Administrador total con facultades de sobrecupo y override	5	2026-09-26 14:15:13.043449-03
\.


--
-- Data for Name: suscripciones_push; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suscripciones_push (id, usuario_id, endpoint, p256dh, auth, creado_en) FROM stdin;
\.


--
-- Data for Name: tipos_acreditacion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tipos_acreditacion (id, codigo, descripcion, requiere_actividad) FROM stdin;
1	ACCESO_GENERAL	Ingreso al predio del Auditorio Polo Saavedra	f
2	ACTIVIDAD_AULA	Ingreso a conferencia o panel en aula temÃ¡tica	t
3	TALLER	ParticipaciÃ³n en taller prÃ¡ctico con cupo limitado	t
4	MASTERCLASS	Clase magistral con expositor principal	t
\.


--
-- Data for Name: usuario_roles_adicionales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuario_roles_adicionales (usuario_id, rol_id, asignado_en) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, dni_pasaporte, evento_id, nombre, apellido, email, celular, rol_principal_id, estado_inscripcion_id, foto_url, foto_metadata, creado_en, actualizado_en) FROM stdin;
\.


--
-- Name: actividades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actividades_id_seq', 6, true);


--
-- Name: blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blacklist_id_seq', 1, false);


--
-- Name: categorias_tematicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categorias_tematicas_id_seq', 6, true);


--
-- Name: confirmaciones_asistencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.confirmaciones_asistencia_id_seq', 1, false);


--
-- Name: encuesta_opciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuesta_opciones_id_seq', 5, true);


--
-- Name: encuesta_preguntas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuesta_preguntas_id_seq', 3, true);


--
-- Name: encuesta_respuestas_detalles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuesta_respuestas_detalles_id_seq', 1, false);


--
-- Name: encuestas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuestas_id_seq', 1, true);


--
-- Name: estados_inscripcion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.estados_inscripcion_id_seq', 5, true);


--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eventos_id_seq', 2, true);


--
-- Name: homologaciones_expositores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.homologaciones_expositores_id_seq', 1, false);


--
-- Name: logs_auditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logs_auditoria_id_seq', 2, true);


--
-- Name: operadores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.operadores_id_seq', 5, true);


--
-- Name: puntos_acceso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.puntos_acceso_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 8, true);


--
-- Name: suscripciones_push_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suscripciones_push_id_seq', 1, false);


--
-- Name: tipos_acreditacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tipos_acreditacion_id_seq', 4, true);


--
-- Name: acreditaciones acreditaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acreditaciones
    ADD CONSTRAINT acreditaciones_pkey PRIMARY KEY (id);


--
-- Name: actividades actividades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_pkey PRIMARY KEY (id);


--
-- Name: blacklist blacklist_dni_pasaporte_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_dni_pasaporte_key UNIQUE (dni_pasaporte);


--
-- Name: blacklist blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blacklist
    ADD CONSTRAINT blacklist_pkey PRIMARY KEY (id);


--
-- Name: categorias_tematicas categorias_tematicas_nombre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorias_tematicas
    ADD CONSTRAINT categorias_tematicas_nombre_key UNIQUE (nombre);


--
-- Name: categorias_tematicas categorias_tematicas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorias_tematicas
    ADD CONSTRAINT categorias_tematicas_pkey PRIMARY KEY (id);


--
-- Name: certificados certificados_codigo_verificacion_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_codigo_verificacion_key UNIQUE (codigo_verificacion);


--
-- Name: certificados certificados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_pkey PRIMARY KEY (id);


--
-- Name: configuraciones_sistema configuraciones_sistema_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuraciones_sistema
    ADD CONSTRAINT configuraciones_sistema_pkey PRIMARY KEY (clave);


--
-- Name: confirmaciones_asistencia confirmaciones_asistencia_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.confirmaciones_asistencia
    ADD CONSTRAINT confirmaciones_asistencia_pkey PRIMARY KEY (id);


--
-- Name: confirmaciones_asistencia confirmaciones_asistencia_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.confirmaciones_asistencia
    ADD CONSTRAINT confirmaciones_asistencia_token_hash_key UNIQUE (token_hash);


--
-- Name: encuesta_opciones encuesta_opciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_opciones
    ADD CONSTRAINT encuesta_opciones_pkey PRIMARY KEY (id);


--
-- Name: encuesta_preguntas encuesta_preguntas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_preguntas
    ADD CONSTRAINT encuesta_preguntas_pkey PRIMARY KEY (id);


--
-- Name: encuesta_respuestas_detalles encuesta_respuestas_detalles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas_detalles
    ADD CONSTRAINT encuesta_respuestas_detalles_pkey PRIMARY KEY (id);


--
-- Name: encuesta_respuestas encuesta_respuestas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas
    ADD CONSTRAINT encuesta_respuestas_pkey PRIMARY KEY (id);


--
-- Name: encuestas encuestas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuestas
    ADD CONSTRAINT encuestas_pkey PRIMARY KEY (id);


--
-- Name: estados_inscripcion estados_inscripcion_codigo_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estados_inscripcion
    ADD CONSTRAINT estados_inscripcion_codigo_key UNIQUE (codigo);


--
-- Name: estados_inscripcion estados_inscripcion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estados_inscripcion
    ADD CONSTRAINT estados_inscripcion_pkey PRIMARY KEY (id);


--
-- Name: eventos eventos_codigo_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT eventos_codigo_key UNIQUE (codigo);


--
-- Name: eventos eventos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT eventos_pkey PRIMARY KEY (id);


--
-- Name: homologaciones_expositores homologaciones_expositores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homologaciones_expositores
    ADD CONSTRAINT homologaciones_expositores_pkey PRIMARY KEY (id);


--
-- Name: homologaciones_expositores homologaciones_expositores_usuario_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homologaciones_expositores
    ADD CONSTRAINT homologaciones_expositores_usuario_id_key UNIQUE (usuario_id);


--
-- Name: logs_auditoria logs_auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs_auditoria
    ADD CONSTRAINT logs_auditoria_pkey PRIMARY KEY (id);


--
-- Name: operadores operadores_email_institucional_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operadores
    ADD CONSTRAINT operadores_email_institucional_key UNIQUE (email_institucional);


--
-- Name: operadores operadores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operadores
    ADD CONSTRAINT operadores_pkey PRIMARY KEY (id);


--
-- Name: puntos_acceso puntos_acceso_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.puntos_acceso
    ADD CONSTRAINT puntos_acceso_pkey PRIMARY KEY (id);


--
-- Name: roles roles_nombre_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_nombre_key UNIQUE (nombre);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: suscripciones_push suscripciones_push_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suscripciones_push
    ADD CONSTRAINT suscripciones_push_endpoint_key UNIQUE (endpoint);


--
-- Name: suscripciones_push suscripciones_push_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suscripciones_push
    ADD CONSTRAINT suscripciones_push_pkey PRIMARY KEY (id);


--
-- Name: tipos_acreditacion tipos_acreditacion_codigo_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipos_acreditacion
    ADD CONSTRAINT tipos_acreditacion_codigo_key UNIQUE (codigo);


--
-- Name: tipos_acreditacion tipos_acreditacion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipos_acreditacion
    ADD CONSTRAINT tipos_acreditacion_pkey PRIMARY KEY (id);


--
-- Name: encuesta_respuestas uq_encuesta_usuario; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas
    ADD CONSTRAINT uq_encuesta_usuario UNIQUE (encuesta_id, usuario_id);


--
-- Name: usuarios uq_usuario_dni_evento; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT uq_usuario_dni_evento UNIQUE (dni_pasaporte, evento_id);


--
-- Name: certificados uq_usuario_tipo_certificado; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT uq_usuario_tipo_certificado UNIQUE (usuario_id, tipo_certificado);


--
-- Name: usuario_roles_adicionales usuario_roles_adicionales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuario_roles_adicionales
    ADD CONSTRAINT usuario_roles_adicionales_pkey PRIMARY KEY (usuario_id, rol_id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: idx_acreditaciones_actividad; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_acreditaciones_actividad ON public.acreditaciones USING btree (actividad_id);


--
-- Name: idx_acreditaciones_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_acreditaciones_timestamp ON public.acreditaciones USING btree (timestamp_acreditacion);


--
-- Name: idx_acreditaciones_usuario; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_acreditaciones_usuario ON public.acreditaciones USING btree (usuario_id);


--
-- Name: idx_acreditaciones_usuario_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_acreditaciones_usuario_fecha ON public.acreditaciones USING btree (usuario_id, punto_acceso_id, timestamp_acreditacion DESC);


--
-- Name: idx_certificados_codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_certificados_codigo ON public.certificados USING btree (codigo_verificacion);


--
-- Name: idx_certificados_evento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_certificados_evento ON public.certificados USING btree (evento_id);


--
-- Name: idx_certificados_usuario; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_certificados_usuario ON public.certificados USING btree (usuario_id);


--
-- Name: idx_encuesta_opciones_pregunta; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuesta_opciones_pregunta ON public.encuesta_opciones USING btree (pregunta_id);


--
-- Name: idx_encuesta_preguntas_encuesta; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuesta_preguntas_encuesta ON public.encuesta_preguntas USING btree (encuesta_id);


--
-- Name: idx_encuesta_respuestas_detalles_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuesta_respuestas_detalles_cat ON public.encuesta_respuestas_detalles USING btree (categoria_tematica_id);


--
-- Name: idx_encuesta_respuestas_detalles_preg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuesta_respuestas_detalles_preg ON public.encuesta_respuestas_detalles USING btree (pregunta_id);


--
-- Name: idx_encuesta_respuestas_detalles_resp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuesta_respuestas_detalles_resp ON public.encuesta_respuestas_detalles USING btree (respuesta_id);


--
-- Name: idx_encuesta_respuestas_encuesta; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuesta_respuestas_encuesta ON public.encuesta_respuestas USING btree (encuesta_id);


--
-- Name: idx_encuesta_respuestas_usuario; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuesta_respuestas_usuario ON public.encuesta_respuestas USING btree (usuario_id);


--
-- Name: idx_encuestas_etapa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuestas_etapa ON public.encuestas USING btree (etapa, activa);


--
-- Name: idx_encuestas_evento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_encuestas_evento ON public.encuestas USING btree (evento_id);


--
-- Name: idx_usuarios_dni_evento; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_usuarios_dni_evento ON public.usuarios USING btree (dni_pasaporte, evento_id);


--
-- Name: idx_usuarios_estado; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usuarios_estado ON public.usuarios USING btree (estado_inscripcion_id);


--
-- Name: idx_usuarios_evento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usuarios_evento ON public.usuarios USING btree (evento_id);


--
-- Name: idx_usuarios_rol; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usuarios_rol ON public.usuarios USING btree (rol_principal_id);


--
-- Name: usuarios trigger_intercept_blacklist; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_intercept_blacklist BEFORE INSERT ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.trg_check_blacklist();


--
-- Name: acreditaciones acreditaciones_actividad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acreditaciones
    ADD CONSTRAINT acreditaciones_actividad_id_fkey FOREIGN KEY (actividad_id) REFERENCES public.actividades(id) ON DELETE RESTRICT;


--
-- Name: acreditaciones acreditaciones_operador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acreditaciones
    ADD CONSTRAINT acreditaciones_operador_id_fkey FOREIGN KEY (operador_id) REFERENCES public.operadores(id) ON DELETE RESTRICT;


--
-- Name: acreditaciones acreditaciones_punto_acceso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acreditaciones
    ADD CONSTRAINT acreditaciones_punto_acceso_id_fkey FOREIGN KEY (punto_acceso_id) REFERENCES public.puntos_acceso(id) ON DELETE RESTRICT;


--
-- Name: acreditaciones acreditaciones_tipo_acreditacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acreditaciones
    ADD CONSTRAINT acreditaciones_tipo_acreditacion_id_fkey FOREIGN KEY (tipo_acreditacion_id) REFERENCES public.tipos_acreditacion(id) ON DELETE RESTRICT;


--
-- Name: acreditaciones acreditaciones_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acreditaciones
    ADD CONSTRAINT acreditaciones_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: actividades actividades_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE CASCADE;


--
-- Name: actividades actividades_punto_acceso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_punto_acceso_id_fkey FOREIGN KEY (punto_acceso_id) REFERENCES public.puntos_acceso(id) ON DELETE RESTRICT;


--
-- Name: actividades actividades_tipo_acreditacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_tipo_acreditacion_id_fkey FOREIGN KEY (tipo_acreditacion_id) REFERENCES public.tipos_acreditacion(id) ON DELETE RESTRICT;


--
-- Name: certificados certificados_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE SET NULL;


--
-- Name: certificados certificados_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: confirmaciones_asistencia confirmaciones_asistencia_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.confirmaciones_asistencia
    ADD CONSTRAINT confirmaciones_asistencia_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: encuesta_opciones encuesta_opciones_categoria_tematica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_opciones
    ADD CONSTRAINT encuesta_opciones_categoria_tematica_id_fkey FOREIGN KEY (categoria_tematica_id) REFERENCES public.categorias_tematicas(id) ON DELETE SET NULL;


--
-- Name: encuesta_opciones encuesta_opciones_pregunta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_opciones
    ADD CONSTRAINT encuesta_opciones_pregunta_id_fkey FOREIGN KEY (pregunta_id) REFERENCES public.encuesta_preguntas(id) ON DELETE CASCADE;


--
-- Name: encuesta_preguntas encuesta_preguntas_categoria_tematica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_preguntas
    ADD CONSTRAINT encuesta_preguntas_categoria_tematica_id_fkey FOREIGN KEY (categoria_tematica_id) REFERENCES public.categorias_tematicas(id) ON DELETE SET NULL;


--
-- Name: encuesta_preguntas encuesta_preguntas_encuesta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_preguntas
    ADD CONSTRAINT encuesta_preguntas_encuesta_id_fkey FOREIGN KEY (encuesta_id) REFERENCES public.encuestas(id) ON DELETE CASCADE;


--
-- Name: encuesta_respuestas_detalles encuesta_respuestas_detalles_categoria_tematica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas_detalles
    ADD CONSTRAINT encuesta_respuestas_detalles_categoria_tematica_id_fkey FOREIGN KEY (categoria_tematica_id) REFERENCES public.categorias_tematicas(id) ON DELETE SET NULL;


--
-- Name: encuesta_respuestas_detalles encuesta_respuestas_detalles_opcion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas_detalles
    ADD CONSTRAINT encuesta_respuestas_detalles_opcion_id_fkey FOREIGN KEY (opcion_id) REFERENCES public.encuesta_opciones(id) ON DELETE SET NULL;


--
-- Name: encuesta_respuestas_detalles encuesta_respuestas_detalles_pregunta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas_detalles
    ADD CONSTRAINT encuesta_respuestas_detalles_pregunta_id_fkey FOREIGN KEY (pregunta_id) REFERENCES public.encuesta_preguntas(id) ON DELETE CASCADE;


--
-- Name: encuesta_respuestas_detalles encuesta_respuestas_detalles_respuesta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas_detalles
    ADD CONSTRAINT encuesta_respuestas_detalles_respuesta_id_fkey FOREIGN KEY (respuesta_id) REFERENCES public.encuesta_respuestas(id) ON DELETE CASCADE;


--
-- Name: encuesta_respuestas encuesta_respuestas_encuesta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas
    ADD CONSTRAINT encuesta_respuestas_encuesta_id_fkey FOREIGN KEY (encuesta_id) REFERENCES public.encuestas(id) ON DELETE CASCADE;


--
-- Name: encuesta_respuestas encuesta_respuestas_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas
    ADD CONSTRAINT encuesta_respuestas_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: encuesta_respuestas encuesta_respuestas_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuesta_respuestas
    ADD CONSTRAINT encuesta_respuestas_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: encuestas encuestas_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encuestas
    ADD CONSTRAINT encuestas_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE CASCADE;


--
-- Name: homologaciones_expositores homologaciones_expositores_funcionario_anulador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homologaciones_expositores
    ADD CONSTRAINT homologaciones_expositores_funcionario_anulador_id_fkey FOREIGN KEY (funcionario_anulador_id) REFERENCES public.operadores(id) ON DELETE SET NULL;


--
-- Name: homologaciones_expositores homologaciones_expositores_funcionario_validador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homologaciones_expositores
    ADD CONSTRAINT homologaciones_expositores_funcionario_validador_id_fkey FOREIGN KEY (funcionario_validador_id) REFERENCES public.operadores(id) ON DELETE SET NULL;


--
-- Name: homologaciones_expositores homologaciones_expositores_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.homologaciones_expositores
    ADD CONSTRAINT homologaciones_expositores_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: logs_auditoria logs_auditoria_usuario_afectado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs_auditoria
    ADD CONSTRAINT logs_auditoria_usuario_afectado_id_fkey FOREIGN KEY (usuario_afectado_id) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: operadores operadores_punto_acceso_default_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operadores
    ADD CONSTRAINT operadores_punto_acceso_default_id_fkey FOREIGN KEY (punto_acceso_default_id) REFERENCES public.puntos_acceso(id) ON DELETE RESTRICT;


--
-- Name: operadores operadores_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operadores
    ADD CONSTRAINT operadores_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roles(id);


--
-- Name: suscripciones_push suscripciones_push_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suscripciones_push
    ADD CONSTRAINT suscripciones_push_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: usuario_roles_adicionales usuario_roles_adicionales_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuario_roles_adicionales
    ADD CONSTRAINT usuario_roles_adicionales_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: usuario_roles_adicionales usuario_roles_adicionales_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuario_roles_adicionales
    ADD CONSTRAINT usuario_roles_adicionales_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: usuarios usuarios_estado_inscripcion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_estado_inscripcion_id_fkey FOREIGN KEY (estado_inscripcion_id) REFERENCES public.estados_inscripcion(id) ON DELETE RESTRICT;


--
-- Name: usuarios usuarios_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE RESTRICT;


--
-- Name: usuarios usuarios_rol_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_rol_principal_id_fkey FOREIGN KEY (rol_principal_id) REFERENCES public.roles(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict hPbZhfsIISlKdoS8prtMglNM8QJ9au31tJuQqYUZifulmLoqH5Mfc8zo1piaG3u

