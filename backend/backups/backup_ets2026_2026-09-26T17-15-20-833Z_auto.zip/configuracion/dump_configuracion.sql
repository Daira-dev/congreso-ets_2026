--
-- PostgreSQL database dump
--

\restrict 1OLVMLMRebUzev0lcIaOOvlUDA1l3iOJ5xRzg1bzM7D8nuiMq5mSpaHqDToywir

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: eventos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventos (id, codigo, nombre, lema, descripcion, anio, fecha_inicio, fecha_fin, horario_apertura, horario_cierre, lugar_nombre, direccion, ciudad, cupo_maximo, estado, activo, creado_en) FROM stdin;
1	ETS_2026	1er Congreso de EducaciÃ³n TÃ©cnica Superior 2026	\N	EdiciÃ³n inaugural en Auditorio Polo Saavedra	2026	2026-11-06	2026-11-06	08:00	18:30	\N	\N	\N	400	PUBLICADO	t	2026-09-26 14:15:13.105012-03
2	ETS_2027	2do Congreso de EducaciÃ³n TÃ©cnica Superior 2027	\N	EdiciÃ³n de consolidaciÃ³n y nuevas especialidades	2027	2027-11-05	2027-11-05	08:00	18:30	\N	\N	\N	400	PUBLICADO	t	2026-09-26 14:15:13.105012-03
\.


--
-- Data for Name: puntos_acceso; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.puntos_acceso (id, evento_id, nombre, ubicacion_fisica, tipo_punto, activo, creado_en) FROM stdin;
\.


--
-- Data for Name: tipos_acreditacion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tipos_acreditacion (id, codigo, descripcion, requiere_actividad) FROM stdin;
1	ACCESO_GENERAL	Ingreso al predio del Auditorio Polo Saavedra	f
2	ACTIVIDAD_AULA	Ingreso a conferencia o panel en aula temÃ¡tica	t
3	TALLER	ParticipaciÃ³n en taller prÃ¡ctico con cupo limitado	t
4	MASTERCLASS	Clase magistral con expositor principal	t
\.


--
-- Data for Name: actividades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actividades (id, evento_id, nombre, descripcion, tipo_acreditacion_id, punto_acceso_id, cupo_maximo, horario_inicio, horario_fin, disertante_nombre, activo) FROM stdin;
\.


--
-- Data for Name: categorias_tematicas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categorias_tematicas (id, nombre, descripcion, activo, creado_en) FROM stdin;
1	Inteligencia Artificial y Machine Learning	Modelos generativos, agentes y automatizaciÃ³n inteligente	t	2026-09-26 14:15:13.114964-03
2	Ciberseguridad y ProtecciÃ³n de Datos	Defensa de infraestructuras, normativas y forensia digital	t	2026-09-26 14:15:13.114964-03
3	Desarrollo Cloud y Arquitecturas Web	Sistemas distribuidos, microservicios, DevOps y APIs	t	2026-09-26 14:15:13.114964-03
4	RobÃ³tica, AutomatizaciÃ³n e IoT	Sistemas embebidos, sensores y robÃ³tica aplicada	t	2026-09-26 14:15:13.114964-03
5	InserciÃ³n Laboral y PrÃ¡cticas IFTS	PasantÃ­as, articulaciÃ³n con cÃ¡maras empresariales y mentorÃ­as	t	2026-09-26 14:15:13.114964-03
6	Ciencia de Datos y AnalÃ­tica	Big data, visualizaciÃ³n estratÃ©gica y pipelines de datos	t	2026-09-26 14:15:13.114964-03
\.


--
-- Data for Name: configuraciones_sistema; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuraciones_sistema (clave, valor, descripcion, categoria, actualizado_en) FROM stdin;
aforo_maximo_confirmados	{"cupo": 400}	LÃ­mite mÃ¡ximo de inscripciones confirmadas automÃ¡ticas	GENERAL	2026-09-26 14:15:13.099986-03
ventana_reconfirmacion_horas	{"pre_evento_horas": 48, "vigencia_token_horas": 24}	Plazos para el envÃ­o de correos de confirmaciÃ³n y expiraciÃ³n	GENERAL	2026-09-26 14:15:13.099986-03
cron_backup_automatico	{"activo": true, "directorio": "./backups", "diurno_fin": "19:00", "frecuencia": "0 2 * * *", "diurno_activo": true, "diurno_inicio": "08:00", "nocturno_hora": "02:00", "retencion_dias": 15, "nocturno_activo": true, "diurno_intervalo_min": 30}	ProgramaciÃ³n y retenciÃ³n de backups automÃ¡ticos	BACKUP	2026-09-26 14:15:13.099986-03
repositorio_git	{"remoto_url": "", "ruta_local": "/media/nestor/960GB/GIT_Congreso/", "rama_default": "main", "sincronizacion_automatica": false}	ParÃ¡metros del repositorio Git local y sincronizaciÃ³n con remoto	GIT	2026-09-26 14:15:13.099986-03
politica_acreditacion	{"exigir_dni_fisico": true, "mostrar_foto_operador": true, "reloj_animado_credencial": true}	PolÃ­ticas de seguridad operativa en puerta	SEGURIDAD	2026-09-26 14:15:13.099986-03
\.


--
-- Data for Name: encuestas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuestas (id, evento_id, titulo, descripcion, etapa, es_obligatoria, activa, creado_en, actualizado_en) FROM stdin;
1	1	Sondeo de Intereses y Preferencias TemÃ¡ticas ETS 2026/2027	AyÃºdanos a priorizar los prÃ³ximos talleres, masterclasses y disertaciones tÃ©cnicas.	INSCRIPCION	f	t	2026-09-26 14:15:13.121913-03	2026-09-26 14:15:13.121913-03
\.


--
-- Data for Name: encuesta_preguntas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_preguntas (id, encuesta_id, categoria_tematica_id, orden, texto_pregunta, tipo_pregunta, es_obligatoria, peso_ponderacion, activo) FROM stdin;
1	1	\N	1	Â¿CuÃ¡les de las siguientes Ã¡reas tÃ©cnicas consideras fundamentales para tu desarrollo profesional?	OPCION_MULTIPLE	t	1.20	t
2	1	\N	2	Â¿QuÃ© nivel de interÃ©s tienes en profundizar sobre Inteligencia Artificial aplicada en la industria?	CALIFICACION_1_A_5	f	1.00	t
3	1	\N	3	Â¿QuÃ© temÃ¡tica o taller especÃ­fico te gustarÃ­a que se incorpore en la prÃ³xima ediciÃ³n?	TEXTO_ABIERTO	f	1.00	t
\.


--
-- Data for Name: encuesta_opciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_opciones (id, pregunta_id, categoria_tematica_id, orden, texto_opcion, valor_ponderacion) FROM stdin;
1	1	1	1	Inteligencia Artificial y Modelos Predictivos	1.00
2	1	2	2	Ciberseguridad Ofensiva y Defensiva	1.00
3	1	3	3	Desarrollo Cloud & Microservicios	1.00
4	1	4	4	RobÃ³tica e Internet de las Cosas (IoT)	1.00
5	1	5	5	PrÃ¡cticas Profesionalizantes e InserciÃ³n en Empresas	1.00
\.


--
-- Data for Name: estados_inscripcion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.estados_inscripcion (id, codigo, nombre, permite_ingreso, descripcion) FROM stdin;
1	CONFIRMADO	Confirmado	t	InscripciÃ³n activa con cupo asegurado y credencial habilitada
2	LISTA_ESPERA	Lista de Espera	f	Sin cupo inmediato por capacidad de aforo completada (FIFO)
3	SANCIONADO	Sancionado	f	RestricciÃ³n disciplinaria activa por inclusiÃ³n en Lista Negra / Blacklist
4	BAJA_AUTOMATICA	Baja AutomÃ¡tica 48hs	f	No confirmÃ³ asistencia en la ventana de 24hs tras el aviso de 48hs
5	CANCELADO	Cancelado	f	Baja voluntaria o revocada manualmente
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, nombre, descripcion, jerarquia, creado_en) FROM stdin;
1	Estudiante	Estudiante de Nivel TÃ©cnico Superior o afÃ­n	1	2026-09-26 14:15:13.043449-03
2	Docente	Personal acadÃ©mico / Docente	1	2026-09-26 14:15:13.043449-03
3	Expositor	Disertante o Tallerista con requerimiento de homologaciÃ³n	2	2026-09-26 14:15:13.043449-03
4	Autoridad	Autoridad Institucional / Ministerial / Invitado Especial	2	2026-09-26 14:15:13.043449-03
5	Operador	Personal de acreditaciÃ³n en puertas y aulas	3	2026-09-26 14:15:13.043449-03
6	Verificador	Funcionario habilitado para homologar pergaminos de expositores	4	2026-09-26 14:15:13.043449-03
7	Administrador	Personal directivo DETS para control y gestiÃ³n	4	2026-09-26 14:15:13.043449-03
8	Superadmin	Administrador total con facultades de sobrecupo y override	5	2026-09-26 14:15:13.043449-03
\.


--
-- Name: actividades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actividades_id_seq', 6, true);


--
-- Name: categorias_tematicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categorias_tematicas_id_seq', 6, true);


--
-- Name: encuesta_opciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuesta_opciones_id_seq', 5, true);


--
-- Name: encuesta_preguntas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuesta_preguntas_id_seq', 3, true);


--
-- Name: encuestas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuestas_id_seq', 1, true);


--
-- Name: estados_inscripcion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.estados_inscripcion_id_seq', 5, true);


--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eventos_id_seq', 2, true);


--
-- Name: puntos_acceso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.puntos_acceso_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 8, true);


--
-- Name: tipos_acreditacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tipos_acreditacion_id_seq', 4, true);


--
-- PostgreSQL database dump complete
--

\unrestrict 1OLVMLMRebUzev0lcIaOOvlUDA1l3iOJ5xRzg1bzM7D8nuiMq5mSpaHqDToywir

