--
-- PostgreSQL database dump
--

\restrict bwCQR7kDMwjIQrODaq1oEhZ3eKSVCW0ar0jhUsxkgDbjNxMjYSJJH5cfhYFwlN3

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: blacklist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blacklist (id, dni_pasaporte, motivo, registrado_por, registrado_en, activo) FROM stdin;
\.


--
-- Data for Name: operadores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operadores (id, nombre, apellido, email_institucional, punto_acceso_default_id, rol_id, password_hash, activo, creado_en) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, dni_pasaporte, evento_id, nombre, apellido, email, celular, rol_principal_id, estado_inscripcion_id, foto_url, foto_metadata, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: suscripciones_push; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suscripciones_push (id, usuario_id, endpoint, p256dh, auth, creado_en) FROM stdin;
\.


--
-- Data for Name: usuario_roles_adicionales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuario_roles_adicionales (usuario_id, rol_id, asignado_en) FROM stdin;
\.


--
-- Name: blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.blacklist_id_seq', 1, false);


--
-- Name: operadores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.operadores_id_seq', 5, true);


--
-- Name: suscripciones_push_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suscripciones_push_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

\unrestrict bwCQR7kDMwjIQrODaq1oEhZ3eKSVCW0ar0jhUsxkgDbjNxMjYSJJH5cfhYFwlN3

