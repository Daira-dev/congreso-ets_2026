--
-- PostgreSQL database dump
--

\restrict dGVPXjhrR8Q3Js29iP15V0l1mECAuSO6ySh0njU1c04e67gYIQ7RUcuMHUqn9OL

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: acreditaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acreditaciones (id, usuario_id, operador_id, tipo_acreditacion_id, actividad_id, punto_acceso_id, es_manual, motivo_manual, tipo_movimiento, timestamp_acreditacion) FROM stdin;
\.


--
-- Data for Name: certificados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.certificados (id, codigo_verificacion, usuario_id, evento_id, tipo_certificado, horas_catedra, emitido_en, metadata) FROM stdin;
\.


--
-- Data for Name: confirmaciones_asistencia; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.confirmaciones_asistencia (id, usuario_id, token_hash, emitido_en, expira_en, confirmado_en, ip_confirmacion) FROM stdin;
\.


--
-- Data for Name: encuesta_respuestas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_respuestas (id, encuesta_id, usuario_id, rol_id, ip_origen, creado_en) FROM stdin;
\.


--
-- Data for Name: encuesta_respuestas_detalles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.encuesta_respuestas_detalles (id, respuesta_id, pregunta_id, opcion_id, categoria_tematica_id, valor_numerico, respuesta_texto) FROM stdin;
\.


--
-- Data for Name: homologaciones_expositores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.homologaciones_expositores (id, usuario_id, estado_homologacion, documentacion_presentada, observaciones, funcionario_validador_id, fecha_validacion, funcionario_anulador_id, fecha_anulacion, motivo_anulacion, actualizado_en) FROM stdin;
\.


--
-- Data for Name: logs_auditoria; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logs_auditoria (id, evento, actor_usuario, usuario_afectado_id, detalles, ip_origen, "timestamp") FROM stdin;
1	BAJA_AUTOMATICA_48HS	CRON_SISTEMA	\N	{"evento_id": 1, "bajas_count": 0}	\N	2026-09-26 14:15:20.801122-03
2	CRON_48HS_DESPACHADO	SISTEMA	\N	{"lotes": 0, "evento_id": 1, "total_confirmados": 0}	\N	2026-09-26 14:15:20.831665-03
\.


--
-- Name: confirmaciones_asistencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.confirmaciones_asistencia_id_seq', 1, false);


--
-- Name: encuesta_respuestas_detalles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encuesta_respuestas_detalles_id_seq', 1, false);


--
-- Name: homologaciones_expositores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.homologaciones_expositores_id_seq', 1, false);


--
-- Name: logs_auditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logs_auditoria_id_seq', 2, true);


--
-- PostgreSQL database dump complete
--

\unrestrict dGVPXjhrR8Q3Js29iP15V0l1mECAuSO6ySh0njU1c04e67gYIQ7RUcuMHUqn9OL

