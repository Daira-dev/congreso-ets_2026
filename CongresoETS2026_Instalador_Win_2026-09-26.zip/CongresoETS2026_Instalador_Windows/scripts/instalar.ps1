<#
.SYNOPSIS
    Instalador maestro del Sistema Congreso ETS 2026 para Windows 10 y Windows 11.
.DESCRIPTION
    Orquesta la verificación previa de dependencias y servicios, la selección interactiva
    del directorio de destino, la copia de archivos, aprovisionamiento de PostgreSQL,
    generación de credenciales criptográficas, compilación de paquetes y creación de
    accesos directos.
#>

# Forzar UTF-8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Determinar directorios clave
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$installerRoot = Split-Path -Parent $scriptDir

# Soporte dual: Paquete autocontenido (app_payload) vs Entorno de desarrollo
$payloadDir = Join-Path $installerRoot "app_payload"
if (Test-Path $payloadDir) {
    $projectSourceRoot = $payloadDir
    Write-Info "Modo de ejecucion: Paquete autonomo autocontenido detectado."
} else {
    $projectSourceRoot = Split-Path -Parent $installerRoot
    Write-Info "Modo de ejecucion: Repositorio de desarrollo detectado."
}

# Cargar módulos auxiliares
. "$scriptDir\utilidades.ps1"
. "$scriptDir\verificar_servicios.ps1"
. "$scriptDir\configurar_db.ps1"

# -----------------------------------------------------------------------------
# FASE 1: Verificación de Servicios Previos y Dependencias
# -----------------------------------------------------------------------------
$auditOk = Invoke-PreflightWizard
if (-not $auditOk) {
    Write-WarningMsg "El instalador no puede continuar sin los componentes obligatorios."
    Write-Host "Presione cualquier tecla para salir..." -ForegroundColor Gray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# -----------------------------------------------------------------------------
# FASE 2: Selección de Carpeta de Destino
# -----------------------------------------------------------------------------
Show-Header "Paso 2: Seleccion de Directorio de Instalacion"

Write-Host "  El instalador copiara todos los archivos y configuraciones del sistema" -ForegroundColor White
Write-Host "  en la carpeta que usted determine a continuacion." -ForegroundColor Gray
Write-Host ""

$carpetaDefault = "C:\CongresoETS2026"
$rutaDestino = Show-FolderPicker -Descripcion "Seleccione la carpeta donde se instalara Congreso ETS 2026" -CarpetaPorDefecto $carpetaDefault

Write-Host ""
Write-Info "Carpeta seleccionada: $rutaDestino"

# Validar / Crear directorio destino
try {
    if (-not (Test-Path $rutaDestino)) {
        Write-Info "Creando directorio destino: $rutaDestino ..."
        $null = New-Item -ItemType Directory -Path $rutaDestino -Force
    }

    # Probar permisos de escritura
    $testFile = "$rutaDestino\.test_permiso_instalador"
    [System.IO.File]::WriteAllText($testFile, "test")
    Remove-Item $testFile -Force
    Write-Success "Directorio valido con permisos de escritura confirmados."
}
catch {
    Write-ErrorMsg "No se pudo escribir en el directorio seleccionado: $_"
    Write-Host "Presione cualquier tecla para salir..." -ForegroundColor Gray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# -----------------------------------------------------------------------------
# FASE 3: Copia y Despliegue de Archivos del Sistema
# -----------------------------------------------------------------------------
Show-Header "Paso 3: Copia y Despliegue de Archivos"

Write-Info "Origen:  $projectSourceRoot"
Write-Info "Destino: $rutaDestino"
Write-Host ""

# Lista de carpetas y archivos a copiar
$carpetasACopiar = @("backend", "frontend", "scripts", "manuales", "certs")
$exclusiones = @("node_modules", ".next", ".git", ".env", "dist", "coverage")

foreach ($carpeta in $carpetasACopiar) {
    $origenSub = Join-Path $projectSourceRoot $carpeta
    $destinoSub = Join-Path $rutaDestino $carpeta

    if (Test-Path $origenSub) {
        Write-Host "  -> Copiando modulo '$carpeta'..." -ForegroundColor Cyan

        # Utilizar robocopy para copia veloz excluyendo node_modules y caches
        $roboParams = @(
            $origenSub,
            $destinoSub,
            "/E",
            "/XD", "node_modules", ".next", ".git", "dist", "backups",
            "/XF", "*.log", ".env",
            "/NFL", "/NDL", "/NJH", "/NJS", "/nc", "/ns", "/np"
        )
        & robocopy @roboParams | Out-Null
        Write-Success "Modulo '$carpeta' desplegado."
    } else {
        Write-WarningMsg "No se encontro la carpeta origen '$carpeta'."
    }
}

# Copiar scripts lanzadores desde las plantillas
$plantillasDir = Join-Path $installerRoot "plantillas"
Copy-Item "$plantillasDir\Iniciar_Congreso.bat" -Destination "$rutaDestino\Iniciar_Congreso.bat" -Force
Copy-Item "$plantillasDir\Detener_Congreso.bat" -Destination "$rutaDestino\Detener_Congreso.bat" -Force
Write-Success "Scripts de arranque y control (Iniciar_Congreso.bat / Detener_Congreso.bat) copiados."

# Copiar archivos raíz (package.json, README si existen)
if (Test-Path "$projectSourceRoot\package.json") {
    Copy-Item "$projectSourceRoot\package.json" -Destination "$rutaDestino\package.json" -Force
}

# -----------------------------------------------------------------------------
# FASE 4: Configuración e Inicialización de Base de Datos
# -----------------------------------------------------------------------------
$dbConfig = $null
$dbExito = Invoke-DatabaseSetup -RutaDestino $rutaDestino -DbConfigResult ([ref]$dbConfig)

if (-not $dbExito) {
    Write-WarningMsg "No se pudo completar la inicializacion automatica de la base de datos."
    Write-Host "  Puede inicializar manualmente ejecutando schema_3fn.sql y seed.sql mas tarde." -ForegroundColor Yellow
    Write-Host "  ¿Desea continuar con el resto de la instalacion? [S/N]: " -NoNewline -ForegroundColor Cyan
    $resp = Read-Host
    if ($resp.Trim().ToUpper() -ne "S") {
        exit 1
    }
}

# -----------------------------------------------------------------------------
# FASE 5: Generación de Entorno y Seguridad Criptográfica
# -----------------------------------------------------------------------------
Show-Header "Paso 5: Generacion de Parametros y Claves Criptograficas"

$envDestino = "$rutaDestino\backend\.env"
$templateEnv = "$plantillasDir\backend.env.template"

if (Test-Path $templateEnv) {
    $envContent = Get-Content $templateEnv -Raw

    # Clave de base de datos
    $dbUrl = if ($dbConfig) { $dbConfig.Url } else { "postgresql://postgres:postgres@localhost:5432/congreso_ets2026" }
    $envContent = $envContent.Replace("{{DATABASE_URL}}", $dbUrl)

    # Claves aleatorias de alta entropía
    $cryptoKey = New-CryptoKeyHex
    $cronSecret = "cron_sec_" + (New-CryptoKeyHex).Substring(0, 24)

    $envContent = $envContent.Replace("{{ENCRYPTION_KEY}}", $cryptoKey)
    $envContent = $envContent.Replace("{{CRON_SECRET}}", $cronSecret)

    Set-Content -Path $envDestino -Value $envContent -Encoding UTF8
    Write-Success "Archivo de configuracion 'backend\.env' generado con clave criptografica AES-256 propia."
} else {
    Write-WarningMsg "No se encontro la plantilla backend.env.template."
}

# -----------------------------------------------------------------------------
# FASE 6: Instalación de Dependencias de Node.js
# -----------------------------------------------------------------------------
Show-Header "Paso 6: Instalacion de Dependencias (NPM Install)"

Write-Host "  Instalando paquetes de backend y frontend. Esto puede demorar unos minutos..." -ForegroundColor Yellow
Write-Host ""

# Backend
Write-Info "Instalando paquetes de Backend..."
Push-Location "$rutaDestino\backend"
& npm install --no-audit --no-fund
if ($LASTEXITCODE -eq 0) {
    Write-Success "Dependencias de Backend instaladas correctamente."
} else {
    Write-WarningMsg "npm install en Backend arrojo advertencias."
}
Pop-Location

# Frontend
Write-Info "Instalando paquetes de Frontend..."
Push-Location "$rutaDestino\frontend"
& npm install --no-audit --no-fund
if ($LASTEXITCODE -eq 0) {
    Write-Success "Dependencias de Frontend instaladas correctamente."
} else {
    Write-WarningMsg "npm install en Frontend arrojo advertencias."
}
Pop-Location

# -----------------------------------------------------------------------------
# FASE 7: Accesos Directos y Finalización
# -----------------------------------------------------------------------------
Show-Header "Paso 7: Creacion de Accesos Directos y Finalizacion"

# Acceso directo en el Escritorio
$desktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop)
$shortcutPath = Join-Path $desktopPath "Congreso ETS 2026.lnk"
$targetBat = Join-Path $rutaDestino "Iniciar_Congreso.bat"

$creado = New-WindowsShortcut `
    -ShortcutPath $shortcutPath `
    -TargetPath $targetBat `
    -WorkingDirectory $rutaDestino `
    -Description "Iniciar Plataforma Congreso ETS 2026 - DETS GCABA"

if ($creado) {
    Write-Success "Acceso directo creado en el Escritorio: 'Congreso ETS 2026.lnk'"
}

# Resumen final
Show-Header "Instalacion Completada con Exito"

Write-Host "  ========================================================================" -ForegroundColor Green
Write-Host "   EL SISTEMA CONGRESO ETS 2026 HA SIDO INSTALADO CORRECTAMENTE          " -ForegroundColor White
Write-Host "  ========================================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Ruta de instalacion : $rutaDestino" -ForegroundColor White
Write-Host "  Servidor Web        : http://localhost:3000" -ForegroundColor White
Write-Host "  Backend API         : http://localhost:4000" -ForegroundColor White
Write-Host "  Control del sistema : Iniciar_Congreso.bat / Detener_Congreso.bat" -ForegroundColor Gray
Write-Host ""
Write-Host "  ¿Desea iniciar el sistema inmediatamente en este equipo? [S/N]: " -NoNewline -ForegroundColor Cyan
$iniciarYa = Read-Host

if ($iniciarYa.Trim().ToUpper() -eq "S") {
    Write-Info "Lanzando Congreso ETS 2026..."
    Start-Process -FilePath "$rutaDestino\Iniciar_Congreso.bat" -WorkingDirectory $rutaDestino
}

Write-Host ""
Write-Host "  Gracias por utilizar el instalador de Congreso ETS 2026." -ForegroundColor Green
Write-Host "  Presione cualquier tecla para cerrar esta ventana..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
