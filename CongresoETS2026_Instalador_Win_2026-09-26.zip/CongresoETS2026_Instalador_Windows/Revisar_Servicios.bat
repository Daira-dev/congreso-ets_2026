@echo off
setlocal EnableDelayedExpansion
title Diagnostico de Servicios - Congreso ETS 2026

echo ========================================================================
echo   DIAGNOSTICO DE SERVICIOS Y PRERREQUISITOS - CONGRESO ETS 2026
echo ========================================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "
    $scriptDir = Split-Path -Parent '%~dp0'
    . '%~dp0scripts\utilidades.ps1'
    . '%~dp0scripts\verificar_servicios.ps1'
    $items = @()
    $ok = Audit-SystemServices -ResultadosAudit ([ref]$items)
    Show-AuditSummaryTable -Items $items
    if ($ok) {
        Write-Host '  TODOS LOS REQUISITOS OBLIGATORIOS ESTAN DISPONIBLES [OK]' -ForegroundColor Green
    } else {
        Write-Host '  FALTAN COMPONENTES. REVISE LA LISTA ANTERIOR.' -ForegroundColor Red
    }
"

echo.
pause
