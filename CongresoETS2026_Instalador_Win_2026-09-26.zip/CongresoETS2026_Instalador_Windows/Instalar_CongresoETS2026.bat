@echo off
setlocal EnableDelayedExpansion
title Instalador del Sistema - Congreso ETS 2026

:: ============================================================================
:: Instalador Sistema Congreso ETS 2026 - Windows 10 / Windows 11
:: DETS - GCABA
:: ============================================================================

echo.
echo  ========================================================================
echo    CONGRESO ETS 2026 - DETS GCABA
echo    Instalador para Microsoft Windows 10 y 11 (64-bit)
echo  ========================================================================
echo.

:: 1. Verificar si se ejecuta con permisos de Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [AVISO] Se requieren privilegios de Administrador para instalar servicios
    echo          y configurar componentes en Windows.
    echo.
    echo  Solicitando autorizacion de Control de Cuentas de Usuario (UAC)...
    echo.
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: 2. Posicionarse en la carpeta donde reside el instalador
cd /d "%~dp0"

:: 3. Verificar existencia del script de PowerShell
if not exist "%~dp0scripts\instalar.ps1" (
    echo  [ERROR CRITICO] No se encontro el archivo de instalacion:
    echo          %~dp0scripts\instalar.ps1
    echo.
    echo  Asegurese de extraer todos los archivos antes de ejecutar este instalador.
    echo.
    pause
    exit /b 1
)

:: 4. Lanzar el asistente de PowerShell con politicas de ejecucion liberadas
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\instalar.ps1"

if %errorlevel% neq 0 (
    echo.
    echo  [AVISO] El instalador finalizo con advertencias o fue cancelado por el usuario.
    echo.
    pause
)
