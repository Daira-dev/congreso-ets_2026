# Manual de Instalación y Despliegue en Windows 10 y Windows 11
## Sistema de Gestión Integral – Congreso ETS 2026 (DETS - GCABA)

Este manual documenta el procedimiento completo para instalar, auditar y ejecutar la plataforma **Congreso ETS 2026** en equipos con sistemas operativos **Microsoft Windows 10 y Windows 11 (64-bit)**.

---

## 📋 1. Requisitos del Sistema

### Hardware Mínimo Recomendado
- **Procesador:** Intel Core i3 / AMD Ryzen 3 o superior (x64).
- **Memoria RAM:** 4 GB mínimo (8 GB recomendado).
- **Espacio en Disco:** 3 GB de espacio libre disponible.
- **Red:** Conexión a Internet para la descarga inicial de paquetes e interacción con correo SMTP.

### Software Previo Requerido (Prerrequisitos)
El instalador audita y verifica automáticamente la presencia de estos dos componentes:
1. **Node.js LTS (Versión 18.18.0 o superior; recomendado v20.x o v22.x LTS):**
   - Descarga oficial: [https://nodejs.org/es/download](https://nodejs.org/es/download)
   - *Nota:* Al instalar Node.js, asegúrese de marcar la casilla *"Add to PATH"*.
2. **PostgreSQL Database Server (Versión 14, 15, 16 o 17):**
   - Descarga oficial (instalador EDB para Windows): [https://www.enterprisedb.com/downloads/postgres-postgresql-downloads](https://www.enterprisedb.com/downloads/postgres-postgresql-downloads)
   - Durante la instalación, recuerde la contraseña asignada al superusuario `postgres` y el puerto (habitualmente `5432` o `5433`).

---

## 🚀 2. Proceso de Instalación Paso a Paso

### Paso 1: Ejecutar el Instalador
1. Ubique la carpeta `windows-installer` dentro de los archivos del proyecto.
2. Haga **doble clic** sobre el archivo:
   ```cmd
   Instalar_CongresoETS2026.bat
   ```
3. El sistema solicitará confirmación de **Control de Cuentas de Usuario (UAC)** para obtener permisos de Administrador. Haga clic en **Sí**.

---

### Paso 2: Auditoría Automática de Servicios y Dependencias
Antes de copiar cualquier archivo, el instalador ejecuta una verificación en tiempo real de los servicios locales y presenta una tabla diagnóstica:

```text
 ==========================================================================
   ESTADO DE SERVICIOS Y PRERREQUISITOS DEL SISTEMA
 ==========================================================================

 [ OK       ] Node.js Runtime              : Instalado (v20.12.0)
 [ OK       ] NPM Package Manager          : Instalado (v10.5.0)
 [ OK       ] PostgreSQL Database          : Instalado y activo en puerto 5432
 [ OK       ] Puertos Web (3000 / 4000)    : Puertos 3000 y 4000 disponibles
```

#### ¿Qué ocurre si falta algún servicio?
Si el instalador detecta que falta Node.js o que PostgreSQL no está instalado o su servicio de Windows está detenido:
- El componente se marcará en **rojo `[ FALTA ]`** o **amarillo `[ DETENIDO ]`**.
- El instalador desplegará un menú interactivo:
  - **`[1]`** Abre directamente el navegador en la página oficial de descarga de Node.js.
  - **`[2]`** Abre directamente la página del instalador de PostgreSQL para Windows.
  - **`[3]`** Abre la consola de Servicios de Windows (`services.msc`) para iniciar el servicio de PostgreSQL.
  - **`[R]`** Vuelve a auditar el sistema inmediatamente una vez completada la instalación de los programas faltantes.
  - **`[Q]`** Cancela la instalación.

> El instalador **no avanzará** a la copia de archivos hasta que todos los servicios obligatorios se encuentren listos y verificados.

---

### Paso 3: Selección de la Carpeta Destino
Una vez cubiertas todas las falencias de servicios:
1. El instalador abrirá una ventana gráfica de exploración de carpetas de Windows (*Folder Browser Dialog*).
2. Podrá elegir cualquier ubicación o unidad de disco (por ejemplo: `C:\CongresoETS2026` o `D:\Sistemas\CongresoETS2026`).
3. El instalador validará automáticamente los permisos de escritura y el espacio en disco.

---

### Paso 4: Copia de Archivos y Aprovisionamiento
El instalador:
1. Despliega los módulos de **Backend API**, **Frontend Web** y scripts del sistema de forma optimizada.
2. Copia los scripts de control (`Iniciar_Congreso.bat` y `Detener_Congreso.bat`).

---

### Paso 5: Asistente de Base de Datos PostgreSQL
El instalador solicitará los datos de conexión con el PostgreSQL local:
- **Host:** (Por defecto: `localhost`)
- **Puerto:** (Detectado automáticamente: `5432` o `5433`)
- **Usuario:** (Por defecto: `postgres`)
- **Contraseña:** (La contraseña que definió al instalar PostgreSQL)

El instalador:
1. Comprueba la conexión de red con el motor de base de datos.
2. Crea automáticamente la base de datos `congreso_ets2026` con codificación `UTF-8`.
3. Ejecuta el esquema relacional normalizado en 3FN (`schema_3fn.sql`).
4. Inserta los datos maestros y configuraciones institucionales (`seed.sql`).

---

### Paso 6: Configuración de Seguridad Criptográfica
El instalador genera un archivo `.env` en la carpeta `backend` configurando:
- Cadena de conexión protegida hacia PostgreSQL.
- **Clave Criptográfica Simétrica AES-256-CBC:** Clave de 32 bytes (64 caracteres hexadecimales) generada aleatoriamente con entropía criptográfica para proteger los códigos QR de los gafetes y credenciales.
- Secreto aleatorio para tareas programadas de recordatorios y cron.
- Parámetros de correo institucional.

---

### Paso 7: Instalación de Paquetes (`npm install`)
El instalador descarga y enlaza automáticamente las dependencias requeridas tanto para el backend como para el frontend.

---

### Paso 8: Accesos Directos
Se creará automáticamente en el **Escritorio de Windows** un acceso directo:
- **`Congreso ETS 2026.lnk`**

---

---

## 🎮 3. Control y Operación Diaria del Sistema

### Iniciar la Plataforma
Tiene dos alternativas sencillas:
1. **Doble clic en el acceso directo del Escritorio:** `"Congreso ETS 2026"`
2. O ejecutar desde la carpeta instalada:
   ```cmd
   Iniciar_Congreso.bat
   ```
El script:
- Inicia el servidor Backend en el puerto `4000`.
- Inicia el servidor Frontend en el puerto `3000`.
- Abre de forma automática el navegador web predeterminado en:
  👉 **`http://localhost:3000`**

### Acceso Administrativo y Operativo
Para ingresar al panel de control, acceda a **`http://localhost:3000/login`**:
- **Superadmin (Jerarquía 5 - Control Total):**
  - Correo: `superadmin.congreso@bue.edu.ar`
- **Administrador DETS (Jerarquía 4 - Gestión Académica y Operativa):**
  - Correo: `admin@ifts04.edu.ar`
- **Operador de Puerta / Acreditaciones (Jerarquía 3 - Molinetes y Aforo):**
  - Correo: `operador1.puerta@bue.edu.ar`

### Detener la Plataforma
Cuando termine de utilizar el sistema o antes de apagar el equipo:
1. Ejecute desde la carpeta de instalación:
   ```cmd
   Detener_Congreso.bat
   ```
El script localizará y cerrará ordenadamente los procesos en los puertos 3000 y 4000.

---

## 🛡️ 4. Reglas de Negocio Clave en la Plataforma

1. **Gestión de Participantes Sancionados:**
   - Todo asistente incluido en la **Lista Negra (`blacklist`)** se cataloga de forma automática en la categoría propia **`Sancionado`**, impidiendo que distorsione o infle la Lista de Espera de vacantes.
   - La **Lista de Espera** queda reservada exclusivamente para aspirantes que aguardan cupos disponibles según el orden de llegada FIFO.
2. **Exclusividad de Diplomas y Certificados con Diseñador WYSIWYG:**
   - La emisión y envío de diplomas está autorizada **únicamente para asistentes y estudiantes**. Los operadores y directivos no reciben diplomas del sistema.
   - El sistema incorpora un **Editor Visual WYSIWYG** en `/admin?tab=certificados` que permite personalizar textos, colores y firmantes con descarga de prueba en PDF vectorial.
   - Los participantes deben completar la Encuesta de Calidad obligatoria para habilitar la descarga del PDF (bloqueo pedagógico; los administradores cuentan con bypass de auditoría). El cuestionario cuenta con un **Diseñador WYSIWYG** con previsualizador móvil y de escritorio en `/admin?tab=encuestas`.
3. **Credencial Oficial en Hoja A4 Única:**
   - La impresión de credenciales físicas está estandarizada para ocupar estrictamente 1 hoja A4 con guía de corte y doblado (10 × 15 cm) para portacredenciales.
4. **Navegación en 2 Filas y Menú Hamburguesa:**
   - La barra de accesos a CRUDs se presenta en dos filas simétricas para que todos los módulos quepan horizontalmente en cualquier monitor sin desbordes.
5. **Alertas Institucionales:**
   - 100% de alertas, confirmaciones y mensajes operativos se presentan mediante **SweetAlert2**, sin cuadros de diálogo nativos del navegador.

---

## 🔍 5. Herramienta Rápida de Diagnóstico
Si en algún momento desea verificar el estado de los servicios sin realizar una instalación completa, haga doble clic en:
```cmd
windows-installer\Revisar_Servicios.bat
```
Este script muestra el estado actual de Node.js, NPM, PostgreSQL y la disponibilidad de los puertos.

---

## ❓ 6. Preguntas Frecuentes y Solución de Problemas

#### 1. ¿Qué hacer si PowerShell muestra un mensaje de "Directiva de ejecución restringida"?
No debe preocuparse. El archivo `.bat` principal (`Instalar_CongresoETS2026.bat`) invoca PowerShell con el modificador `-ExecutionPolicy Bypass`, lo que permite ejecutar la instalación sin alterar la directiva global de seguridad de Windows.

#### 2. Mi PostgreSQL usa el puerto 5433 en lugar del 5432
El instalador detecta automáticamente si el puerto 5433 está activo y lo sugiere por defecto en el asistente de base de datos. Solo presione Enter para aceptarlo.

#### 3. El puerto 3000 o 4000 aparece ocupado
Si la tabla de diagnóstico indica que los puertos están en uso, verifique que no haya otra instancia del sistema o de desarrollo abierta. Puede ejecutar `Detener_Congreso.bat` para liberar los puertos.
